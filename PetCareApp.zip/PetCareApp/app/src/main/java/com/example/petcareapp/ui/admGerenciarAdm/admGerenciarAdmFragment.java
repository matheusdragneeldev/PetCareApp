package com.example.petcareapp.ui.admGerenciarAdm;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admGerenciarAdmFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admGerenciarAdmFragment extends Fragment {

    String emailUsuarioAtual, nomeClicadoAdm;
    Integer idUsuarioAtual, idAdmClicado;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada
    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;

    EditText admEmailAdm, admNomeAdm, etPesquisarAdm;
    TextView tvAdmEmailAdm, tvAdmNomeAdm;
    Button btAdmAlterarDadosAdm, btnAdmSelecinarFotoAdm, admDeletarAdm;
    RecyclerView listaGerenciarAdm;
    ImageView admImgAdm;
    ImageButton btVoltarAdmAdm;
    FrameLayout frameLayoutGerenciarAdm;

    ArrayList<Integer> listaIdGerenciarAdm = new ArrayList<>();
    ArrayList<Bitmap> listaFotoGerenciarAdm = new ArrayList<>();
    ArrayList<String> listaEmailGerenciarAdm = new ArrayList<>();
    ArrayList<String> listaNomeGerenciarAdm = new ArrayList<>();

    ArrayList<MainModelGerenciarAdm> mainModels = new ArrayList<>();
    MainAdapterGerenciarAdm mainAdapter;

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admGerenciarAdmFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admGerenciarTutorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admGerenciarAdmFragment newInstance(String param1, String param2) {
        admGerenciarAdmFragment fragment = new admGerenciarAdmFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                admImgAdm.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_adm_gerenciar_adm, container, false);

        admEmailAdm = view.findViewById(R.id.admEmailAdm);
        admNomeAdm = view.findViewById(R.id.admNomeAdm);
        admDeletarAdm = view.findViewById(R.id.admDeletarAdm);
        etPesquisarAdm = view.findViewById(R.id.etPesquisarAdm);
        listaGerenciarAdm = view.findViewById(R.id.listaGerenciarAdm);
        tvAdmEmailAdm = view.findViewById(R.id.tvAdmEmailAdm);
        tvAdmNomeAdm = view.findViewById(R.id.tvAdmNomeAdm);
        btnAdmSelecinarFotoAdm = view.findViewById(R.id.btnAdmSelecionarFotoAdm);
        frameLayoutGerenciarAdm = view.findViewById(R.id.frameLayoutGerenciarAdm);
        admImgAdm = view.findViewById(R.id.admImgAdm);
        btAdmAlterarDadosAdm = view.findViewById(R.id.btAdmAlterarDadosAdm);
        btVoltarAdmAdm = view.findViewById(R.id.btVoltarAdmAdm);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaGerenciarAdm.setLayoutManager(layoutManager);
        listaGerenciarAdm.setItemAnimator(new DefaultItemAnimator());

        // Inicia MainAdapter
        mainAdapter = new MainAdapterGerenciarAdm(getActivity(),mainModels);
        // Set MainAdapter para ListaTutor


        mainAdapter = new MainAdapterGerenciarAdm(getActivity(), mainModels, new MainAdapterGerenciarAdm.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelGerenciarAdm model) {
                try {
                    // Obtenha o nome do administrador do modelo
                    idAdmClicado = Integer.valueOf(model.getListaIdGerenciarAdm());
                    admImgAdm.setImageDrawable(null);

                    Connection con = ConexaoMysql.conectar();
                    String sql = "SELECT * FROM adm_info_adm WHERE id_login = ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idAdmClicado);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        idAdmClicado = Integer.valueOf(rs.getString("id_login"));
                        admEmailAdm.setText(rs.getString("email"));

                        // Preenche a imagem
                        byte[] imgBytes = rs.getBytes("foto");
                        if (imgBytes != null) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.length);
                            admImgAdm.setImageBitmap(bitmap);
                        }

                        admNomeAdm.setText(rs.getString("nome"));
                        nomeClicadoAdm = rs.getString("nome");
                    }

                    if (admImgAdm.getDrawable() == null) {
                        btnAdmSelecinarFotoAdm.setAlpha(1);
                    } else {
                        btnAdmSelecinarFotoAdm.setAlpha(0);
                    }

                    funMostrarDadosAdm();
                    admEmailAdm.setEnabled(false);

                    rs.close();
                    stmt.close();
                    con.close();
                } catch (Exception e) {
                    throw new RuntimeException("Erro ao buscar detalhes do administrador", e);
                }
            }
        });

        listaGerenciarAdm.setAdapter(mainAdapter);

        etPesquisarAdm.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().isEmpty()) {
                    updateRecyclerView(); // Mostra toda a lista se não houver texto
                } else {
                    funPesquisarAdm(s.toString()); // Faz o filtro
                }
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        btAdmAlterarDadosAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAdmAlterarDadosAdm();
            }
        });

        admDeletarAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idAdmClicado == null) {
                    Toast.makeText(getActivity(), "Nenhum administrador selecionado!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (idAdmClicado == 1) {
                    Toast.makeText(getActivity(), "Você não tem permissão para excluir esse administrador!", Toast.LENGTH_SHORT).show();
                    return;
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Você tem certeza que deseja excluir o administrador " + nomeClicadoAdm + "?")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarAdm();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });

        btVoltarAdmAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funEsconderDadosAdm();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funEsconderDadosAdm();
        funListaAdm();
        etPesquisarAdm.setText(null);
    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    public void funListaAdm() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, email, foto, nome FROM adm_info_adm";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdGerenciarAdm.clear();
            listaEmailGerenciarAdm.clear();
            listaFotoGerenciarAdm.clear();
            listaNomeGerenciarAdm.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                Integer id = rs.getInt("id_login");
                String email = rs.getString("email");
                byte[] fotoBytes = rs.getBytes("foto");
                String nome = rs.getString("nome");

                // Adicionar os dados nas listas
                listaIdGerenciarAdm.add(id);

                if (fotoBytes != null) {
                    // Converter a foto para Bitmap
                    Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                    // Chama o método para arredondar a imagem
                    Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                    listaFotoGerenciarAdm.add(roundedBitmap);
                } else {
                    listaFotoGerenciarAdm.add(null);
                }

                listaEmailGerenciarAdm.add(email);
                listaNomeGerenciarAdm.add(nome);
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            // Atualize o RecyclerView com os dados
            updateRecyclerView();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModels.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdGerenciarAdm.size(); i++) {
            MainModelGerenciarAdm model = new MainModelGerenciarAdm(listaIdGerenciarAdm.get(i), listaFotoGerenciarAdm.get(i), listaEmailGerenciarAdm.get(i), listaNomeGerenciarAdm.get(i));
            mainModels.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapter.notifyDataSetChanged();
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }

    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(Integer idClinica) {
        byte[] imgBytesAtual = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM adm_info_clinica WHERE id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idClinica);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imgBytesAtual;
    }

    public void funPesquisarAdm(String termo) {
        ArrayList<MainModelGerenciarAdm> listaFiltrada = new ArrayList<>();
        String filtro = termo.toLowerCase().trim();

        for (int i = 0; i < listaIdGerenciarAdm.size(); i++) {
            String nome = listaNomeGerenciarAdm.get(i).toLowerCase();
            String email = listaEmailGerenciarAdm.get(i).toLowerCase();

            if (nome.contains(filtro) || email.contains(filtro)) {
                listaFiltrada.add(new MainModelGerenciarAdm(
                        listaIdGerenciarAdm.get(i),
                        listaFotoGerenciarAdm.get(i),
                        listaEmailGerenciarAdm.get(i),
                        listaNomeGerenciarAdm.get(i)
                ));
            }
        }

        mainAdapter.atualizarLista(listaFiltrada);
    }

    public void funAdmAlterarDadosAdm() {
        String nomeAdm = admNomeAdm.getText().toString().trim();

        if (nomeAdm.isEmpty()) { admNomeAdm.setError("Campo obrigatório"); return; }

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "UPDATE adm SET nome = ? WHERE id_adm = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nomeAdm);
            stmt.setInt(2, idAdmClicado);
            stmt.executeUpdate();

            stmt.close();
            con.close();

            nomeClicadoAdm = nomeAdm;
            funListaAdm();

            Toast.makeText(getActivity(), "Dados atualizados com sucesso!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public void funDeletarAdm() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM login WHERE id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idAdmClicado);
            stmt.execute();

            stmt.close();
            con.close();

            funEsconderDadosAdm();
            funListaAdm();

            idAdmClicado = null;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funDesativarCampos() {
        admEmailAdm.setEnabled(false);
        admNomeAdm.setEnabled(false);
    }

    public void funAtivarCampos() {
        admEmailAdm.setEnabled(true);
        admNomeAdm.setEnabled(true);
    }

    public void funLimparCampos() {
        admEmailAdm.setText(null);
        admNomeAdm.setText(null);
        admNomeAdm.setError(null);
    }

    public void funEsconderDadosAdm() {
        frameLayoutGerenciarAdm.setVisibility(GONE);
        btnAdmSelecinarFotoAdm.setVisibility(GONE);
        admImgAdm.setVisibility(GONE);
        tvAdmEmailAdm.setVisibility(GONE);
        admEmailAdm.setVisibility(GONE);
        tvAdmNomeAdm.setVisibility(GONE);
        admNomeAdm.setVisibility(GONE);
        btAdmAlterarDadosAdm.setVisibility(GONE);
        admDeletarAdm.setVisibility(GONE);
        btVoltarAdmAdm.setVisibility(GONE);
        etPesquisarAdm.setVisibility(VISIBLE);
        listaGerenciarAdm.setVisibility(VISIBLE);
    }

    public void funMostrarDadosAdm() {
        etPesquisarAdm.setVisibility(GONE);
        listaGerenciarAdm.setVisibility(GONE);
        btVoltarAdmAdm.setVisibility(VISIBLE);
        frameLayoutGerenciarAdm.setVisibility(VISIBLE);
        btnAdmSelecinarFotoAdm.setVisibility(VISIBLE);
        admImgAdm.setVisibility(VISIBLE);
        tvAdmEmailAdm.setVisibility(VISIBLE);
        admEmailAdm.setVisibility(VISIBLE);
        tvAdmNomeAdm.setVisibility(VISIBLE);
        admNomeAdm.setVisibility(VISIBLE);
        btAdmAlterarDadosAdm.setVisibility(VISIBLE);
        admDeletarAdm.setVisibility(VISIBLE);
        admNomeAdm.setError(null);
    }
}