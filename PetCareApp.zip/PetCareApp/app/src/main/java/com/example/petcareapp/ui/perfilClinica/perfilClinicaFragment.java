package com.example.petcareapp.ui.perfilClinica;


import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link perfilClinicaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class perfilClinicaFragment extends Fragment {
    // Declarando os componentes e variaveis
    Button btnSalvarDadosClinica, btnAlterarDadosClinica, btnSalvarEnderecoClinica, btnAlterarEnderecoClinica,btnSelecionarFotoClinica;
    EditText nomeClinica, telefoneClinica, crmvClinica, funcionamentoClinica, descricaoClinica;
    EditText logradouroClinica, numeroClinica, complementoClinica, bairroClinica, cepClinica, cidadeClinica;
    String emailUsuarioAtual;
    Integer idUsuarioAtual;
    TextView textCountDescClinica;
    ImageView imgClinica;
    Spinner spEstadoClinica;
    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;
    boolean imageChanged = false;
    String idClinica;

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public perfilClinicaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment perfilClinicaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static perfilClinicaFragment newInstance(String param1, String param2) {
        perfilClinicaFragment fragment = new perfilClinicaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                imgClinica.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                                if (btnSelecionarFotoClinica.getAlpha() == 0) {
                                    btnSalvarDadosClinica.setVisibility(VISIBLE);
                                    btnAlterarDadosClinica.setVisibility(GONE);
                                } else if (btnSelecionarFotoClinica.getAlpha() == 1) {
                                    // Esconde o botão de selecionar a foto
                                }

                                // Verificando se a ImageView está vazia
                                Drawable drawable = imgClinica.getDrawable();

                                if (drawable != null) {
                                    btnSelecionarFotoClinica.setAlpha(0);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_perfil_clinica, container, false);
        // Chamando a função para iniciar os componentes
        btnSalvarDadosClinica = view.findViewById(R.id.btSalvarClinica);
        btnAlterarDadosClinica = view.findViewById(R.id.btAlterarClinica);
        nomeClinica = view.findViewById(R.id.nomeClinica);
        telefoneClinica = view.findViewById(R.id.telefoneClinica);
        crmvClinica = view.findViewById(R.id.crmvClinica);
        textCountDescClinica = view.findViewById(R.id.textCountDescClinica);
        descricaoClinica = view.findViewById(R.id.descricaoClinica);
        funcionamentoClinica = view.findViewById(R.id.funcionamentoClinica);
        // Endereço da clinica
        btnSalvarEnderecoClinica = view.findViewById(R.id.btSalvarEnderecoClinica);
        btnAlterarEnderecoClinica = view.findViewById(R.id.btAlterarEnderecoClinica);
        logradouroClinica = view.findViewById(R.id.etLogradouroClinica);
        numeroClinica = view.findViewById(R.id.etNumeroClinica);
        complementoClinica = view.findViewById(R.id.etComplementoClinica);
        bairroClinica = view.findViewById(R.id.etBairroClinica);
        cepClinica = view.findViewById(R.id.etCepClinica);
        cidadeClinica = view.findViewById(R.id.etCidadeClinica);
        spEstadoClinica = view.findViewById(R.id.spEstadoClinica);
        // Imagem da clinica
        btnSelecionarFotoClinica = view.findViewById(R.id.btnSelecionarFotoClinica);
        imgClinica = view.findViewById(R.id.imgClinica);

        // Botao salvar comeca com visibilidade GONE
        btnSalvarDadosClinica.setVisibility(GONE);
        btnSalvarEnderecoClinica.setVisibility(GONE);
        btnSelecionarFotoClinica.setEnabled(false);
        btnSelecionarFotoClinica.setAlpha(1);

        // Chamando a função para iniciar os componentes
        desativarCampos();
        desativarCamposEnderecoClinica();

        // Botão selecionar foto
        btnSelecionarFotoClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funSelecionarFoto();
            }
        });
        // Botão alterar os da clinica
        btnAlterarDadosClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnSalvarDadosClinica.setVisibility(VISIBLE);
                btnAlterarDadosClinica.setVisibility(GONE);
                btnSelecionarFotoClinica.setEnabled(true);
                ativarCampos();
            }
        });
        // Botão salvar os dados clinica
        btnSalvarDadosClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drawable drawable = imgClinica.getDrawable();
                // Se os campos estiverem vazios, mostrar um Toast de mensagem!
                if(drawable == null){
                    Toast.makeText(getContext(), "Adicione uma imagem da clínica", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(nomeClinica.getText().toString().trim().isEmpty()){
                    nomeClinica.setError("campo obrigatório");
                    return;
                }
                if(crmvClinica.getText().toString().trim().isEmpty()){
                    crmvClinica.setError("campo obrigatório");
                    return;
                }
                ativarCampos();
                btnSalvarDadosClinica.setVisibility(GONE);
                btnAlterarDadosClinica.setVisibility(VISIBLE);
                funAtualizarClinica();
                desativarCampos();
                btnSelecionarFotoClinica.setEnabled(false);
            }
        });
        // Botõs alterar o endereço da clinica
        btnAlterarEnderecoClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnSalvarEnderecoClinica.setVisibility(VISIBLE);
                btnAlterarEnderecoClinica.setVisibility(GONE);
                ativarCamposEnderecoClinica();
            }
        });
        // Contador de caracteres
        descricaoClinica.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int currentLength = s.length();
                textCountDescClinica.setText(currentLength + "/500");
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
        // Botão salvar endereço da clinica
        btnSalvarEnderecoClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Se os campos estiverem vazios, mostrar um Toast de mensagem avisando para preeencher os campos!
                if (logradouroClinica.getText().toString().trim().isEmpty()){
                    logradouroClinica.setError("campo obrigatório");
                    return;
                }
                if (bairroClinica.getText().toString().trim().isEmpty()){
                    bairroClinica.setError("campo obrigatório");
                    return;
                }
                if (cidadeClinica.getText().toString().trim().isEmpty()){
                    cidadeClinica.setError("campo obrigatório");
                    return;
                }
                ativarCamposEnderecoClinica();
                try {
                    Connection con = ConexaoMysql.conectar();
                    PreparedStatement stmt;
                    String sql;
                    String sql2 = "SELECT * FROM endereco WHERE id_endereco = ?";
                    PreparedStatement stmt2 = con.prepareStatement(sql2);
                    stmt2.setInt(1, idUsuarioAtual);
                    ResultSet rs = stmt2.executeQuery();
                    // Verificando se o endereço já existe
                    while (rs.next()) {
                        // Obtendo os dados do endereço para comparação com os campos que estão no EDITTEXT
                            String logradouro1 = rs.getString("logradouro");
                            String numero1 = rs.getString("numero");
                            String complemento1 = rs.getString("complemento");
                            String bairro1 = rs.getString("bairro");
                            String cidade1 = rs.getString("cidade");
                            String cep1 = rs.getString("cep");
                            String estado1 = rs.getString("estado");
                        if (logradouroClinica.getText().toString().trim().equals(logradouro1) && numeroClinica.getText().toString().trim().equals(numero1)
                            && complementoClinica.getText().toString().trim().equals(complemento1) && bairroClinica.getText().toString().trim().equals(bairro1)
                            && cidadeClinica.getText().toString().trim().equals(cidade1) && cepClinica.getText().toString().trim().equals(cep1)
                            && spEstadoClinica.getSelectedItem().toString().trim().equals(estado1)){

                        }else {
                            sql = "UPDATE endereco SET logradouro = ?, numero = ?, complemento = ?, bairro = ?, cidade = ?, cep = ?, estado = ?  WHERE fk_id_login = ? ;";
                            stmt = con.prepareStatement(sql);
                            stmt.setString(1, logradouroClinica.getText().toString().trim());
                            stmt.setString(2, numeroClinica.getText().toString().trim());
                            stmt.setString(3, complementoClinica.getText().toString().trim());
                            stmt.setString(4, bairroClinica.getText().toString().trim());
                            stmt.setString(5, cidadeClinica.getText().toString().trim());
                            stmt.setString(6, cepClinica.getText().toString().trim());
                            stmt.setString(7, spEstadoClinica.getSelectedItem().toString().trim());
                            stmt.setInt(8, idUsuarioAtual);
                            // Executando a atualização
                            stmt.executeUpdate();
                            // Fechar recursos
                            stmt.close();
                        }
                    }
                        // Fechar recursos
                        rs.close();
                        stmt2.close();
                        con.close();
                        desativarCamposEnderecoClinica();
                    btnAlterarEnderecoClinica.setVisibility(VISIBLE);
                    btnSalvarEnderecoClinica.setVisibility(GONE);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        // Chamando a função para iniciar os componentes
        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        // Obtendo o id do usuário atual
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }
            // Fechar recursos
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // Criar uma lista de estados
        List<String> estadosList = Arrays.asList("Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Distrito Federal",
                "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba",
                "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia",
                "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins");

        // Criar o ArrayAdapter e associar ao Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), R.layout.spinner_text_color, estadosList);
        adapter.setDropDownViewResource(R.layout.spinner_text_color);  // Usar o mesmo layout para os itens dropdown
        spEstadoClinica.setAdapter(adapter);

        // INICIANDO A FUNÇÃO DO SELECT PARA SETAR OS CAMPOS COM OS DADOS DO BANCO DA CLINICA E ENDEREÇO
        if(btnAlterarDadosClinica.getVisibility() == VISIBLE){
            funSelectDados();
        }
        nomeClinica.setError(null);
        crmvClinica.setError(null);
        logradouroClinica.setError(null);
        bairroClinica.setError(null);
        cidadeClinica.setError(null);
    }
    // Função para ativar os campos dos dados da clinica
    public void ativarCampos(){
        nomeClinica.setFocusable(true);
        nomeClinica.setFocusableInTouchMode(true);
        nomeClinica.setCursorVisible(true);
        nomeClinica.setLongClickable(true);

        telefoneClinica.setFocusable(true);
        telefoneClinica.setFocusableInTouchMode(true);
        telefoneClinica.setCursorVisible(true);
        telefoneClinica.setLongClickable(true);

        crmvClinica.setFocusable(true);
        crmvClinica.setFocusableInTouchMode(true);
        crmvClinica.setCursorVisible(true);
        crmvClinica.setLongClickable(true);

        funcionamentoClinica.setFocusable(true);
        funcionamentoClinica.setFocusableInTouchMode(true);
        funcionamentoClinica.setCursorVisible(true);
        funcionamentoClinica.setLongClickable(true);

        descricaoClinica.setFocusable(true);
        descricaoClinica.setFocusableInTouchMode(true);
        descricaoClinica.setCursorVisible(true);
        descricaoClinica.setLongClickable(true);
    }
    // função para desativar os campos dos dados da clinica
    public void desativarCampos(){

        nomeClinica.setFocusable(false);
        nomeClinica.setFocusableInTouchMode(false);
        nomeClinica.setCursorVisible(false);
        nomeClinica.setLongClickable(false);

        telefoneClinica.setFocusable(false);
        telefoneClinica.setFocusableInTouchMode(false);
        telefoneClinica.setCursorVisible(false);
        telefoneClinica.setLongClickable(false);

        crmvClinica.setFocusable(false);
        crmvClinica.setFocusableInTouchMode(false);
        crmvClinica.setCursorVisible(false);
        crmvClinica.setLongClickable(false);

        funcionamentoClinica.setFocusable(false);
        funcionamentoClinica.setFocusableInTouchMode(false);
        funcionamentoClinica.setCursorVisible(false);
        funcionamentoClinica.setLongClickable(false);

        descricaoClinica.setFocusable(false);
        descricaoClinica.setFocusableInTouchMode(false);
        descricaoClinica.setCursorVisible(false);
        descricaoClinica.setLongClickable(false);
    }
    // função para ativar os campos do endereço da clinica
    public void ativarCamposEnderecoClinica(){
        logradouroClinica.setFocusable(true);
        logradouroClinica.setFocusableInTouchMode(true);
        logradouroClinica.setCursorVisible(true);
        logradouroClinica.setLongClickable(true);

        numeroClinica.setFocusable(true);
        numeroClinica.setFocusableInTouchMode(true);
        numeroClinica.setCursorVisible(true);
        numeroClinica.setLongClickable(true);

        cepClinica.setFocusable(true);
        cepClinica.setFocusableInTouchMode(true);
        cepClinica.setCursorVisible(true);
        cepClinica.setLongClickable(true);

        complementoClinica.setFocusable(true);
        complementoClinica.setFocusableInTouchMode(true);
        complementoClinica.setCursorVisible(true);
        complementoClinica.setLongClickable(true);

        bairroClinica.setFocusable(true);
        bairroClinica.setFocusableInTouchMode(true);
        bairroClinica.setCursorVisible(true);
        bairroClinica.setLongClickable(true);

        cidadeClinica.setFocusable(true);
        cidadeClinica.setFocusableInTouchMode(true);
        cidadeClinica.setCursorVisible(true);
        cidadeClinica.setLongClickable(true);

        spEstadoClinica.setFocusable(true);
        spEstadoClinica.setFocusableInTouchMode(true);
        spEstadoClinica.setLongClickable(true);
        spEstadoClinica.setEnabled(true);
    }
    // função para desativar os campos do endereço da clinica
    public void desativarCamposEnderecoClinica(){
        logradouroClinica.setFocusable(false);
        logradouroClinica.setFocusableInTouchMode(false);
        logradouroClinica.setCursorVisible(false);
        logradouroClinica.setLongClickable(false);

        numeroClinica.setFocusable(false);
        numeroClinica.setFocusableInTouchMode(false);
        numeroClinica.setCursorVisible(false);
        numeroClinica.setLongClickable(false);

        cepClinica.setFocusable(false);
        cepClinica.setFocusableInTouchMode(false);
        cepClinica.setCursorVisible(false);
        cepClinica.setLongClickable(false);

        complementoClinica.setFocusable(false);
        complementoClinica.setFocusableInTouchMode(false);
        complementoClinica.setCursorVisible(false);
        complementoClinica.setLongClickable(false);

        bairroClinica.setFocusable(false);
        bairroClinica.setFocusableInTouchMode(false);
        bairroClinica.setCursorVisible(false);
        bairroClinica.setLongClickable(false);

        cidadeClinica.setFocusable(false);
        cidadeClinica.setFocusableInTouchMode(false);
        cidadeClinica.setCursorVisible(false);
        cidadeClinica.setLongClickable(false);

        spEstadoClinica.setFocusable(false);
        spEstadoClinica.setFocusableInTouchMode(false);
        spEstadoClinica.setLongClickable(false);
        spEstadoClinica.setEnabled(false);
    }
    // Função para selecionar os dados da clinica
    public void funSelectDados(){
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM info_clinica WHERE id_clinica = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                // Preenche a imagem da clinica
                byte[] imgBytes = rs.getBytes("foto");
                if (imgBytes != null) {
                    Bitmap bitmap = BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.length);
                    imgClinica.setImageBitmap(bitmap);
                    btnSelecionarFotoClinica.setAlpha(0);
                }
                nomeClinica.setText(rs.getString("nome"));
                telefoneClinica.setText(rs.getString("telefone"));
                crmvClinica.setText(rs.getString("cfmv_crmv"));
                funcionamentoClinica.setText(rs.getString("funcionamento"));
                descricaoClinica.setText(rs.getString("descricao"));
                logradouroClinica.setText(rs.getString("logradouro"));
                numeroClinica.setText(rs.getString("numero"));
                cepClinica.setText(rs.getString("cep"));
                complementoClinica.setText(rs.getString("complemento"));
                bairroClinica.setText(rs.getString("bairro"));
                cidadeClinica.setText(rs.getString("cidade"));

                String estado = rs.getString("estado");
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) spEstadoClinica.getAdapter();
                int position = adapter.getPosition(estado);
                spEstadoClinica.setSelection(position);
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    //FUNCOES PARA SELECIONAR A FOTO DA CLINICA
    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }
    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(String idClinica) {
        byte[] imgBytesAtual = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM clinica WHERE id_clinica = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, idClinica);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }
            // Fechar recursos
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imgBytesAtual;
    }
    // Função para atualizar os dados da clinica
    public void funAtualizarClinica() {

       String nome = nomeClinica.getText().toString().trim();
       String telefone = telefoneClinica.getText().toString().trim();
       String crmv = crmvClinica.getText().toString().trim();
       String descricao = descricaoClinica.getText().toString().trim();
       String funcionamento = funcionamentoClinica.getText().toString().trim();

        // Se a imagem foi alterada
        byte[] imgBytes = null;
        if (imageChanged) {
            // Se uma nova imagem foi selecionada, converte para bytes
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            selectedBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            imgBytes = byteArrayOutputStream.toByteArray();
        } else {
            // Caso a imagem não tenha sido alterada, recupere a imagem existente do banco de dados
            imgBytes = getImgBytesFromDatabase(idClinica);  // Supondo que você tenha um método para recuperar a imagem do banco
        }

        // Atualiza o banco de dados
        try {
            Connection con = ConexaoMysql.conectar();
            String sql;
            PreparedStatement stmt;
            String sql2 = "SELECT * FROM clinica WHERE id_clinica = ?";
            PreparedStatement stmt2 = con.prepareStatement(sql2);
            stmt2.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt2.executeQuery();
            while (rs.next()) {
                // Obtendo os dados da clinica para comparação
                String foto1 = rs.getString("foto");
                String nome1 = rs.getString("nome");
                String telefone1 = rs.getString("telefone");
                String crmv1 = rs.getString("cfmv_crmv");
                String descricao1 = rs.getString("descricao");
                String funcionamento1 = rs.getString("funcionamento");

                // Comparando os dados, aqui esta fazendo a comparação dos campos
                if (nome.equals(nome1) && telefone.equals(telefone1) && crmv.equals(crmv1) && descricao.equals(descricao1) && funcionamento.equals(funcionamento1)) {

            }else {
                if (imageChanged) {
                    // Atualiza com a nova foto, caso tenha sido alterada
                    sql = "UPDATE clinica SET foto=?, nome=?, descricao=?, cfmv_crmv = ?, telefone=?, funcionamento=? WHERE id_clinica = ?";
                    stmt = con.prepareStatement(sql);
                    stmt.setBytes(1, imgBytes);
                    stmt.setString(2, nome);// Define a nova foto
                    stmt.setString(3, descricao);
                    stmt.setString(4, crmv);
                    stmt.setString(5, telefone);
                    stmt.setString(6, funcionamento);
                    stmt.setInt(7, idUsuarioAtual);

                } else {
                    // Se a imagem não foi alterada, atualiza sem tocar na foto
                    sql = "UPDATE clinica SET nome=?, descricao=?, cfmv_crmv = ?, telefone=?, funcionamento=? WHERE id_clinica = ?";
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1, nome);// Define a nova foto
                    stmt.setString(2, descricao);
                    stmt.setString(3, crmv);
                    stmt.setString(4, telefone);
                    stmt.setString(5, funcionamento);
                    stmt.setInt(6, idUsuarioAtual);
                }
                // Executando a atualização
                stmt.executeUpdate();
                // Fechar recursos
                stmt.close();
                // Atualizando a variável de controle de alteração de imagem
                imageChanged = false;
            }
        }
            // Fechar recursos da select do banco que fez a comparação dos dados que já estão no banco
            rs.close();
            stmt2.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
}