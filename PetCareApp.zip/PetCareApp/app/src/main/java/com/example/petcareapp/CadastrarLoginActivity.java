package com.example.petcareapp;

import static android.view.View.GONE;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Arrays;
import java.util.List;

public class CadastrarLoginActivity extends AppCompatActivity {

    EditText cadastrarEmail, cadastrarSenha, cadastrarConfSenha;
    Button btLogincadastrar;
    TextView telaLogin;
    Spinner cadastrarTipoUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Esconde a Action Bar (barra de ação) da sua atividade
        getSupportActionBar().hide();

        // Inicializa o Firebase
        FirebaseApp.initializeApp(this);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastrar_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars =
                    insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializa os componentes
        funIniciarComponentes();

        telaLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tl = new Intent(CadastrarLoginActivity.this, LoginActivity.class);
                startActivity(tl);
                finish();
            }
        });

        btLogincadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = cadastrarEmail.getText().toString().trim();
                String senha = cadastrarSenha.getText().toString().trim();
                String confSenha = cadastrarConfSenha.getText().toString().trim();

                if (email.isEmpty() || senha.isEmpty()) {
                    funMostrarSnackbar(v, 0);
                } else {
                    if(senha.equals(confSenha)){
                        // Cadastra usuário no Firebase/Banco de Dados SQL
                        funCadastrarUsuario(v);
                    } else{
                        funMostrarSnackbar(v, 2);
                    }
                }
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        // Criar a lista de status
        List<String> tipoList = Arrays.asList("Tutor", "Clinica");

        // Criar o ArrayAdapter e associar ao Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_item, tipoList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        cadastrarTipoUsuario.setAdapter(adapter);
    }

    // Função para inicializar componentes
    public void funIniciarComponentes() {
        cadastrarEmail = findViewById(R.id.cadastrarEmail);
        cadastrarSenha = findViewById(R.id.cadastrarSenha);
        cadastrarConfSenha = findViewById(R.id.cadastrarConfSenha);
        btLogincadastrar = findViewById(R.id.btLoginCadastrar);
        telaLogin = findViewById(R.id.telaLogin);
        cadastrarTipoUsuario = findViewById(R.id.cadastrarTipoUsuario);
    }

    // Função para cadastrar usuário no Firebase/Banco de Dados SQL
    public void funCadastrarUsuario(View v) {

        String email = cadastrarEmail.getText().toString().trim();
        String senha = cadastrarSenha.getText().toString().trim();

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, senha)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Cadastra usuário no Banco de Dados SQL
                            try {
                                Connection con = ConexaoMysql.conectar();
                                String sql = "INSERT INTO login(email, tipo_user)VALUES(?,?);";
                                PreparedStatement stmt = con.prepareStatement(sql);
                                stmt.setString(1, email);
                                stmt.setString(2,cadastrarTipoUsuario.getSelectedItem().toString());
                                stmt.execute();

                                stmt.close();
                                con.close();

                                // Navega para a tela de login
                                Intent tl = new Intent(CadastrarLoginActivity.this, LoginActivity.class);
                                startActivity(tl);
                                finish();

                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        } else {
                            // Tratando erros
                            try {
                                throw task.getException(); // Tenta obter uma exceção
                            } catch(FirebaseAuthWeakPasswordException e) { // Senha menor que 6 caracteres
                                funMostrarSnackbar(v, 4);
                            } catch (FirebaseAuthUserCollisionException e) { // Caso o email já exista
                                funMostrarSnackbar(v, 1);
                            } catch (FirebaseAuthInvalidCredentialsException e) { // Caso o email sejá inválido
                                funMostrarSnackbar(v, 5);
                            } catch (Exception e) {
                                funMostrarSnackbar(v, 3);
                            }
                        }
                    }
                });
    }

    // Função para exibir mensagens de erros
    public void funMostrarSnackbar(View v, int indice) {
        String[] mensagens = {"Preencha todos os campos", "E-mail já cadastrado, tente outro",
                "Senha e confirmação de senha não coincidem", "Ocorreu um erro ao tentar realizar o cadastro. Tente novamente",
                "A senha deve ter pelo menos 6 caracteres", "Por favor, insira um e-mail válido"};

        Snackbar snackbar = Snackbar.make(v, mensagens[indice], Snackbar.LENGTH_LONG);
        snackbar.setBackgroundTint(Color.BLACK); // Cor do background
        snackbar.setTextColor(Color.WHITE); // Cor do texto
        snackbar.show(); // Mostra a mensagem
    }

}