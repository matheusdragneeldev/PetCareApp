package com.example.petcareapp.ui.campanha;

public class MainModelCampanha {
    String listaIdCampanha;
    String listaTituloCampanha,listaInicioCampanha,listaEstadoCampanha;



    public MainModelCampanha(String listaIdCampanha, String listaTituloCampanha, String listaInicioCampanha, String listaEstadoCampanha) {
        this.listaIdCampanha = listaIdCampanha;
        this.listaTituloCampanha = listaTituloCampanha;
        this.listaInicioCampanha = listaInicioCampanha;
        this.listaEstadoCampanha = listaEstadoCampanha;
    }

    public String getListaIdCampanha() {
        return listaIdCampanha;
    }

    public String getListaTituloCampanha() {
        return listaTituloCampanha;
    }

    public String getListaInicioCampanha() {
        return listaInicioCampanha;
    }
    public String getListaEstadoCampanha() {
        return listaEstadoCampanha;
    }

}
