package com.example.petcareapp.ui.admFeedback;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;
import com.example.petcareapp.ui.admGerenciarTutor.MainModelGerenciarTutor;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapterFeedback extends RecyclerView.Adapter<MainAdapterFeedback.ViewHolder> {

    private ArrayList<MainModelFeedback> mainModels;
    private Context context;
    private OnItemClickListener listener;

    // Interface para clique no item
    public interface OnItemClickListener {
        void onItemClick(MainModelFeedback model);
    }

    // Construtor com listener
    public MainAdapterFeedback(Context context, ArrayList<MainModelFeedback> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_feedback, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModelFeedback item = mainModels.get(position);

        holder.listaIdFeedback.setText(String.valueOf(item.getListaIdFeedback()));
        holder.listaFotoFeedback.setImageBitmap(mainModels.get(position).getListaFotoFeedback());
        holder.listaEmailFeedback.setText(item.getListaEmailFeedback());
        holder.listaMsgFeedback.setText(item.getListaMsgFeedback());
        holder.listaDataFeedback.setText(item.getListaDataFeedback());

        holder.listaEmailFeedback.setMaxLines(1);
        holder.listaEmailFeedback.setEllipsize(TextUtils.TruncateAt.END);

        holder.listaMsgFeedback.setMaxLines(2);
        holder.listaMsgFeedback.setEllipsize(TextUtils.TruncateAt.END);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            } else {
                Log.e("MainAdapterFeedback", "Listener is null!");
            }
        });
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView listaFotoFeedback;
        TextView listaIdFeedback, listaEmailFeedback, listaMsgFeedback, listaDataFeedback;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaFotoFeedback = itemView.findViewById(R.id.listaFotoFeedback);
            listaIdFeedback = itemView.findViewById(R.id.listaIdFeedback);
            listaEmailFeedback = itemView.findViewById(R.id.listaEmailFeedback);
            listaMsgFeedback = itemView.findViewById(R.id.listaMsgFeedback);
            listaDataFeedback = itemView.findViewById(R.id.listaDataFeedback);
        }
    }

    public void atualizarLista(ArrayList<MainModelFeedback> novaLista) {
        mainModels.clear();
        mainModels.addAll(novaLista);
        notifyDataSetChanged();
    }

}
