package com.example.petcareapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class VaccineReminderWorker extends Worker {

    private static final String TAG = "VaccineReminderWorker";

    public VaccineReminderWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();

        // PASSO 1: VERIFICAR SE O USUÁRIO LOGADO É UM 'TUTOR'
        SharedPreferences sharedPref = context.getSharedPreferences("PetCarePrefs", Context.MODE_PRIVATE);
        String userType = sharedPref.getString("USER_TYPE", ""); // Pega o tipo de usuário

        if (!"Tutor".equalsIgnoreCase(userType)) {
            Log.d(TAG, "Worker encerrado. Usuário não é Tutor, mas sim: " + userType);
            return Result.success(); // Tarefa concluída com sucesso, pois não há o que fazer.
        }

        Log.d(TAG, "Usuário é Tutor. Iniciando verificação de vacinas...");

        // PASSO 2: PREPARAR AS DATAS PARA A CONSULTA
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Calendar cal = Calendar.getInstance();

        // Data de hoje
        String hoje = sdf.format(cal.getTime());

        // Data daqui a 3 dias
        cal.add(Calendar.DAY_OF_YEAR, 3);
        String dataLimite = sdf.format(cal.getTime());

        Log.d(TAG, "Verificando vacinas entre " + hoje + " e " + dataLimite);

        // PASSO 3: CONSULTAR O BANCO DE DADOS
        // IMPORTANTE: Substitua os nomes abaixo pelos nomes reais da sua tabela e colunas!
        final String NOME_TABELA_VACINAS = "vw_lembretes_vacinas";
        final String COLUNA_NOME_PET = "nome_do_pet";
        final String COLUNA_NOME_VACINA = "nome_da_vacina";
        final String COLUNA_DATA_VACINA = "data_da_vacina";
        final String COLUNA_EMAIL_TUTOR = "email_do_tutor";

        // Pega o e-mail do tutor logado para consultar apenas as vacinas dele
        String emailTutor = FirebaseAuth.getInstance().getCurrentUser() != null ? FirebaseAuth.getInstance().getCurrentUser().getEmail() : null;
        if(emailTutor == null) {
            Log.d(TAG, "Worker encerrado. Não foi possível obter o email do usuário logado.");
            return Result.success(); // Não há o que fazer se o usuário não estiver logado.
        }


        try (Connection con = ConexaoMysql.conectar()) {
            // A query agora filtra pelo e-mail do tutor e pelo intervalo de datas
            String query = "SELECT " + COLUNA_NOME_PET + ", " + COLUNA_NOME_VACINA + " FROM " + NOME_TABELA_VACINAS +
                    " WHERE " + COLUNA_DATA_VACINA + " BETWEEN ? AND ? AND " + COLUNA_EMAIL_TUTOR + " = ?";

            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, hoje);
            stmt.setString(2, dataLimite);
            stmt.setString(3, emailTutor);


            ResultSet rs = stmt.executeQuery();

            // PASSO 4: ENVIAR NOTIFICAÇÃO PARA CADA VACINA ENCONTRADA
            while (rs.next()) {
                String petName = rs.getString(COLUNA_NOME_PET);
                String vaccineName = rs.getString(COLUNA_NOME_VACINA);

                Log.d(TAG, "Notificação sendo preparada para: " + vaccineName + " do pet " + petName);

                // Reutiliza o NotificationHelper para criar a notificação
                NotificationHelper.showVaccineReminderNotification(context, petName, vaccineName);
            }

        } catch (Exception e) {
            Log.e(TAG, "Erro ao consultar vacinas no banco de dados", e);
            return Result.failure(); // Indica que a tarefa falhou
        }

        return Result.success(); // Indica que a tarefa foi concluída com sucesso
    }
}