package com.example.petcareapp;

import android.util.Log;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Verifica se a mensagem contém uma carga de dados (data payload).
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());

            // Extrai o remetente e a mensagem do payload
            String sender = remoteMessage.getData().get("sender");
            String message = remoteMessage.getData().get("message");

            // Chama nosso método para mostrar a notificação
            if (sender != null && message != null) {
                NotificationHelper.showNewMessageNotification(this, sender, message);
            }
        }

        // Você também pode lidar com a carga de notificação (notification payload) aqui.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }
    }

    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);
        // Envie este token para o seu servidor para que ele saiba para onde enviar as mensagens.
    }
}