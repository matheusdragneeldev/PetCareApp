package com.example.petcareapp.ui.pet;

import android.graphics.Bitmap;

import java.util.Arrays;
import java.util.Objects;

public class MainModel {
    byte[] listaFotoPet;
    String listaIdPet;
    String listaNomePet;

    public MainModel(byte[] listaFotoPet, String listaIdPet, String listaNomePet) {
        this.listaFotoPet = listaFotoPet;
        this.listaIdPet = listaIdPet;
        this.listaNomePet = listaNomePet;
    }

    public byte[] getListaFotoPet() {
        return listaFotoPet;
    }

    public String getListaIdPet() {
        return listaIdPet;
    }

    public String getListaNomePet() {
        return listaNomePet;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MainModel mainModel = (MainModel) o;
        // Compara todos os campos importantes
        return Objects.equals(listaIdPet, mainModel.listaIdPet) &&
                Objects.equals(listaNomePet, mainModel.listaNomePet) &&
                Arrays.equals(listaFotoPet, mainModel.listaFotoPet); // 'Arrays.equals' para byte[]
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(listaIdPet, listaNomePet);
        result = 31 * result + Arrays.hashCode(listaFotoPet);
        return result;
    }

}
