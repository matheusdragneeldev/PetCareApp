package com.example.petcareapp.ui.campanha;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_LONG;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.petFragment;
import com.google.android.gms.common.server.response.FastParser;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link novaCampanhaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class novaCampanhaFragment extends Fragment {

    String emailUsuarioAtual, dataI,dataF,tipoData;
    Integer idUsuarioAtual, id_ac;
    EditText nomeCampanhaNova, descCampanhaNova, inicioCampanhaNova, fimCampanhaNova, fonteCampanhaNova,
            logradouroEndCampanhaNova, numeroEndCampanhaNova, cepEndCampanhaNova, bairroEndCampanhaNova,
            cidadeEndCampanhaNova, complementoEndCampanhaNova;
    TextView enderecoNova, tvNovaCampanha;
    Spinner estadoEndCampanhaNova;
    Button btCadastrarCampanhaNova;

    ArrayAdapter<String> adapter1; //Adaptador para Startar os dados da lista.
    List<String> estadoList;
    ImageButton btDataInicioNova,btDataFimNova;
    //Formatação data
    String dataStringI = "inicio_campanha", dataStringF = "fim_campanha"  ; // Exemplo da data quando vem do banco de dados
    Date dataInicio,dataFim ; // Converte uma String para um objeto Date

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public novaCampanhaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment novaCampanhaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static novaCampanhaFragment newInstance(String param1, String param2) {
        novaCampanhaFragment fragment = new novaCampanhaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_nova_campanha, container, false);

        nomeCampanhaNova = view.findViewById(R.id.nomeCampanhaNova);
        descCampanhaNova = view.findViewById(R.id.descCampanhaNova);
        inicioCampanhaNova = view.findViewById(R.id.inicioCampanhaNova);
        fimCampanhaNova = view.findViewById(R.id.fimCampanhaNova);
        fonteCampanhaNova = view.findViewById(R.id.fonteCampanhaNova);
        logradouroEndCampanhaNova = view.findViewById(R.id.logradouroEndCampanhaNova);
        numeroEndCampanhaNova = view.findViewById(R.id.numeroEndCampanhaNova);
        cepEndCampanhaNova = view.findViewById(R.id.cepEndCampanhaNova);
        bairroEndCampanhaNova = view.findViewById(R.id.bairroEndCampanhaNova);
        cidadeEndCampanhaNova = view.findViewById(R.id.cidadeEndCampanhaNova);
        complementoEndCampanhaNova = view.findViewById(R.id.complementoEndCampanhaNova);
        estadoEndCampanhaNova = view.findViewById(R.id.estadoEndCampanhaNova);
        enderecoNova=view.findViewById(R.id.enderecoNova);
        btCadastrarCampanhaNova = view.findViewById(R.id.btCadastrarCampanhaNova);
        tvNovaCampanha = view.findViewById(R.id.tvNovaCampanha);


        // Criar a lista de estadoEndCampanha
        estadoList = Arrays.asList("Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Distrito Federal",
                "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba",
                "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia",
                "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins");

        // Criar o ArrayAdapter e associar ao Spinner
        adapter1 = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, estadoList);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        estadoEndCampanhaNova.setAdapter(adapter1);

        btCadastrarCampanhaNova.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funCadastrarCampanha(view);
            }
        });

        // Aplica o filtro de validação
        inicioCampanhaNova.setFilters(new InputFilter[]{ new novaCampanhaFragment.DateInputFilter() });
        fimCampanhaNova.setFilters(new InputFilter[]{ new novaCampanhaFragment.DateInputFilter() });

        inicioCampanhaNova.addTextChangedListener(new TextWatcher() {
            private boolean isUpdatingI;

            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isUpdatingI) return;

                // Remove caracteres não numéricos
                String clean = s.toString().replaceAll("[^\\d]", "");
                if (clean.length() > 8) clean = clean.substring(0, 8);

                StringBuilder out = new StringBuilder();
                for (int i = 0; i < clean.length(); i++) {
                    out.append(clean.charAt(i));
                    if ((i == 1 || i == 3) && i != clean.length() - 1) out.append('/');
                }

                isUpdatingI = true;
                inicioCampanhaNova.setText(out.toString());
                inicioCampanhaNova.setSelection(out.length());
                isUpdatingI = false;
            }
        });

        fimCampanhaNova.addTextChangedListener(new TextWatcher() {
            private boolean isUpdatingF;

            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isUpdatingF) return;

                // Remove caracteres não numéricos
                String clean = s.toString().replaceAll("[^\\d]", "");
                if (clean.length() > 8) clean = clean.substring(0, 8);

                StringBuilder out = new StringBuilder();
                for (int i = 0; i < clean.length(); i++) {
                    out.append(clean.charAt(i));
                    if ((i == 1 || i == 3) && i != clean.length() - 1) out.append('/');
                }

                isUpdatingF = true;
                fimCampanhaNova.setText(out.toString());
                fimCampanhaNova.setSelection(out.length());
                isUpdatingF = false;
            }
        });

        return view;
    }

    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, tipo_user FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static class DateValidator {

        /* Verifica se a string está no formato dd/MM/yyyy e é uma data possível. */
        public static boolean isValidDate(String dateStr) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);           // NÃO aceita 32/13/2025 …

            try {
                java.util.Date date = sdf.parse(dateStr);

                // Opcional: limite de ano (ajuste se quiser)
                int year = Integer.parseInt(dateStr.substring(6));
                return year >= 1900 && year <= 2100;
            } catch (ParseException | NumberFormatException e) {
                return false;
            }
        }
    }

    public class DateInputFilter implements InputFilter {

        @Override
        public CharSequence filter(CharSequence source, int start, int end,
                                   Spanned dest, int dstart, int dend) {

            // Monta como ficará o texto se aceitarmos a digitação
            StringBuilder builder = new StringBuilder(dest);
            builder.replace(dstart, dend, source.subSequence(start, end).toString());
            String result = builder.toString();

            // Remove barras para validar só os dígitos
            String digits = result.replaceAll("[^\\d]", "");

            // Limite absoluto: 8 dígitos (ddMMyyyy)
            if (digits.length() > 8) return "";

            // Validação incremental: DIA
            if (digits.length() >= 1) {
                int diaDezena = Character.getNumericValue(digits.charAt(0));
                if (diaDezena > 3) return "";
            }
            if (digits.length() >= 2) {
                int dia = Integer.parseInt(digits.substring(0, 2));
                if (dia < 1 || dia > 31) return "";
            }

            // Validação incremental: MÊS
            if (digits.length() >= 4) {
                int mes = Integer.parseInt(digits.substring(2, 4));
                if (mes < 1 || mes > 12) return "";
            }

            // Validação incremental: ANO (opcional)
            if (digits.length() == 8) {
                int ano = Integer.parseInt(digits.substring(4, 8));
                if (ano < 1900 || ano > 2100) return "";
            }

            // Tudo OK: aceita a digitação
            return null;
        }
    }

    public void funCadastrarCampanha(View view){
        String nome = nomeCampanhaNova.getText().toString().trim();
        String descricao = descCampanhaNova.getText().toString().trim();
        String fonte = fonteCampanhaNova.getText().toString().trim();
        String logradouro = logradouroEndCampanhaNova.getText().toString().trim();
        String numero = numeroEndCampanhaNova.getText().toString().trim();
        String complemento = complementoEndCampanhaNova.getText().toString().trim();
        String bairro = bairroEndCampanhaNova.getText().toString().trim();
        String cidade = cidadeEndCampanhaNova.getText().toString().trim();
        String cep = cepEndCampanhaNova.getText().toString().trim();
        String inicio = inicioCampanhaNova.getText().toString().trim();
        String fim = fimCampanhaNova.getText().toString().trim();
        String estado = estadoEndCampanhaNova.getSelectedItem().toString();

        if (!(nome.isEmpty()||descricao.isEmpty()||logradouro.isEmpty()||
                bairro.isEmpty()||cidade.isEmpty()||
                inicio.isEmpty()||fim.isEmpty())||estado.isEmpty()){

            // Conversão segura String para java.sql.Date
            java.sql.Date dataSqlI;
            java.sql.Date dataSqlF;
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                dataSqlI = new java.sql.Date(sdf.parse(inicio).getTime());
                dataSqlF = new java.sql.Date(sdf.parse(fim).getTime());
            } catch (ParseException e) {
                // Só deve ocorrer em caso de erro muito improvável
                inicioCampanhaNova.setError("Data inválida");
                fimCampanhaNova.setError("Data inválida");
                Toast.makeText(getActivity(), "Erro ao converter a data", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                Connection con = ConexaoMysql.conectar();
                String sql = "INSERT INTO alerta_campanhas(nome_campanha,desc_campanha,inicio_campanha,fim_campanha," +
                        "fonte_web,fk_id_login) VALUES(?,?,?,?,?,?);";
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, nome);
                stmt.setString(2, descricao);
                stmt.setDate(3,dataSqlI);
                stmt.setDate(4,dataSqlF);
                stmt.setString(5,fonte);
                stmt.setInt(6,idUsuarioAtual);
                stmt.execute();

                sql="SELECT id_alerta_campanha FROM alerta_campanhas ORDER BY id_alerta_campanha DESC LIMIT 1;";
                stmt = con.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()){
                    id_ac = Integer.valueOf(rs.getString("id_alerta_campanha"));
                }

                sql = "INSERT INTO endereco_campanha(logradouro,numero,complemento,bairro,cidade,cep,estado," +
                        "fk_id_alerta_campanhas) VALUES(?,?,?,?,?,?,?,?);";
                stmt = con.prepareStatement(sql);
                stmt.setString(1,logradouro);
                stmt.setString(2,numero);
                stmt.setString(3,complemento);
                stmt.setString(4,bairro);
                stmt.setString(5,cidade);
                stmt.setString(6,cep);
                stmt.setString(7,estado);
                stmt.setInt(8,id_ac);
                stmt.execute();

                stmt.close();
                rs.close();
                con.close();

                NavController navController = Navigation.findNavController(view);
                navController.navigate(R.id.nav_campanha);

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        else {
            Toast.makeText(getActivity(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        }
    }

}