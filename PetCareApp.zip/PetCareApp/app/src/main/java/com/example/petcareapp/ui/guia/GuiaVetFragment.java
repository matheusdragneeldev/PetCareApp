package com.example.petcareapp.ui.guia;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.R;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GuiaVetFragment extends Fragment {

    private EditText etPergunta;
    private Button btnEnviar;
    private TextView tvResposta;
    private ProgressBar progressBar;
    private CardView card_resposta;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public GuiaVetFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_guia_vet, container, false);

        etPergunta = view.findViewById(R.id.et_pergunta);
        btnEnviar = view.findViewById(R.id.btn_enviar);
        tvResposta = view.findViewById(R.id.tv_resposta);
        progressBar = view.findViewById(R.id.progress_bar);
        card_resposta = view.findViewById(R.id.card_resposta);

        btnEnviar.setOnClickListener(v -> {
            String pergunta = etPergunta.getText().toString().trim();
            if (pergunta.isEmpty()) {
                Toast.makeText(getActivity(), "Por favor, digite uma pergunta.", Toast.LENGTH_SHORT).show();
                return;
            }
            gerarResposta(pergunta);
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        card_resposta.setVisibility(GONE);
        etPergunta.setText(null);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Garante que a thread seja desligada quando o fragmento for destruído
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }

    private void gerarResposta(String perguntaUsuario) {
        card_resposta.setVisibility(VISIBLE);
        progressBar.setVisibility(VISIBLE);
        btnEnviar.setEnabled(false);
        tvResposta.setText("Pesquisando informações...");

        String suaChaveApi = "AIzaSyAhAkP_94Zq843OWrMYSEZVa8YeFoDC-ws";

        GenerativeModel gm = new GenerativeModel(
                "gemini-1.5-flash",
                suaChaveApi
        );
        GenerativeModelFutures model = GenerativeModelFutures.from(gm);

        String promptMestre = "Você é o 'Guia Vet PetCare', um assistente de IA especializado em fornecer informações gerais e educacionais sobre a saúde e doenças de animais de estimação (pets). " +
                "REGRAS IMPORTANTES: " +
                "1. FOCO EXCLUSIVO: Responda APENAS a perguntas relacionadas à saúde, bem-estar, sintomas e doenças de animais de estimação e outros animais. " +
                "2. RECUSAR PERGUNTAS FORA DO TEMA: Se o usuário perguntar sobre qualquer outro assunto (carros, celebridades, história, etc.), recuse educadamente a resposta. Diga algo como: 'Meu conhecimento é focado em ajudar com dúvidas sobre a saúde de pets. Não consigo responder sobre outros assuntos.'. " +
                "3. NÃO É UM VETERINÁRIO: Você NUNCA deve fornecer um diagnóstico, prognóstico ou plano de tratamento. Seu papel é estritamente educacional. " +
                "4. AVISO OBRIGATÓRIO: SEMPRE, sem exceção, finalize TODAS as suas respostas com o seguinte aviso em uma nova linha e em negrito: '**IMPORTANTE: Esta informação é apenas para fins educacionais e não substitui uma consulta, diagnóstico ou tratamento veterinário profissional. Se o seu pet não está bem, consulte um médico veterinário qualificado imediatamente.**' " +
                "Agora, responda à seguinte pergunta do usuário, seguindo todas as regras acima: ";

        String promptFinal = promptMestre + perguntaUsuario;
        Content content = new Content.Builder().addText(promptFinal).build();

        ListenableFuture<GenerateContentResponse> response = model.generateContent(content);
        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                String textoResposta = result.getText();
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        tvResposta.setText(textoResposta);
                        progressBar.setVisibility(GONE);
                        btnEnviar.setEnabled(true);
                    });
                }
            }

            @Override
            public void onFailure(Throwable t) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        tvResposta.setText("Erro ao gerar resposta: " + t.getMessage());
                        progressBar.setVisibility(GONE);
                        btnEnviar.setEnabled(true);
                    });
                }
                t.printStackTrace();
            }
        }, executor);
    }
}
