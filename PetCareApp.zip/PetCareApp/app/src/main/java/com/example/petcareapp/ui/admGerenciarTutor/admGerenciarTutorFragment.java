package com.example.petcareapp.ui.admGerenciarTutor;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admGerenciarTutorFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admGerenciarTutorFragment extends Fragment {

    String emailUsuarioAtual, nomeClicadoTutor;
    Integer idUsuarioAtual, idTutorClicado;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada
    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;

    EditText admEmailTutor, admNomeTutor, admTelefoneTutor, etPesquisarTutor, admDescricaoTutor;
    TextView tvAdmEmailTutor, tvAdmNomeTutor, tvAdmTelefoneTutor, tvAdmDesricaoTutor;
    Button btAdmAlterarDadosTutor, btnAdmSelecinarFotoTutor, admDeletarTutor;
    RecyclerView listaGerenciarTutor;
    ImageView admImgTutor;
    ImageButton btVoltarAdmTutor;
    FrameLayout frameLayoutGerenciarTutor;

    // ArrayList<String> arrayListaAllTutor;
    // ArrayList<String> arrayListaFiltradaTutor;

    ArrayList<Integer> listaIdGerenciarTutor = new ArrayList<>();
    ArrayList<Bitmap> listaFotoGerenciarTutor = new ArrayList<>();
    ArrayList<String> listaEmailGerenciarTutor = new ArrayList<>();
    ArrayList<String> listaNomeGerenciarTutor = new ArrayList<>();

    ArrayList<MainModelGerenciarTutor> mainModels = new ArrayList<>();
    MainAdapterGerenciarTutor mainAdapter;

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admGerenciarTutorFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admGerenciarTutorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admGerenciarTutorFragment newInstance(String param1, String param2) {
        admGerenciarTutorFragment fragment = new admGerenciarTutorFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                admImgTutor.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view = inflater.inflate(R.layout.fragment_adm_gerenciar_tutor, container, false);

       admEmailTutor = view.findViewById(R.id.admEmailTutor);
       admNomeTutor = view.findViewById(R.id.admNomeTutor);
       admTelefoneTutor = view.findViewById(R.id.admTelefoneTutor);
       admDeletarTutor = view.findViewById(R.id.admDeletarTutor);
       etPesquisarTutor = view.findViewById(R.id.etPesquisarTutor);
       listaGerenciarTutor = view.findViewById(R.id.listaGerenciarTutor);
       admDescricaoTutor = view.findViewById(R.id.admDescricaoTutor);
       tvAdmEmailTutor = view.findViewById(R.id.tvAdmEmailTutor);
       tvAdmNomeTutor = view.findViewById(R.id.tvAdmNomeTutor);
       tvAdmTelefoneTutor = view.findViewById(R.id.tvAdmTelefoneTutor);
       tvAdmDesricaoTutor = view.findViewById(R.id.tvAdmDescricaoTutor);
       listaGerenciarTutor = view.findViewById(R.id.listaGerenciarTutor);
       btnAdmSelecinarFotoTutor = view.findViewById(R.id.btnAdmSelecionarFotoTutor);
       frameLayoutGerenciarTutor = view.findViewById(R.id.frameLayoutGerenciarTutor);
       admImgTutor = view.findViewById(R.id.admImgTutor);
       btAdmAlterarDadosTutor = view.findViewById(R.id.btAdmAlterarDadosTutor);
       btVoltarAdmTutor = view.findViewById(R.id.btVoltarAdmTutor);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaGerenciarTutor.setLayoutManager(layoutManager);
        listaGerenciarTutor.setItemAnimator(new DefaultItemAnimator());

        // Inicia MainAdapter
        mainAdapter = new MainAdapterGerenciarTutor(getActivity(),mainModels);
        // Set MainAdapter para ListaTutor

        mainAdapter = new MainAdapterGerenciarTutor(getActivity(), mainModels, new MainAdapterGerenciarTutor.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelGerenciarTutor model) {
                try {
                    // Obtenha o nome do tutor do modelo
                    idTutorClicado = Integer.valueOf(model.getListaIdGerenciarTutor());
                    admImgTutor.setImageDrawable(null);

                    Connection con = ConexaoMysql.conectar();
                    String sql = "SELECT * FROM adm_info_tutor WHERE id_login = ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idTutorClicado);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        idTutorClicado = Integer.valueOf(rs.getString("id_login"));
                        admEmailTutor.setText(rs.getString("email"));

                        // Preenche a imagem
                        byte[] imgBytes = rs.getBytes("foto");
                        if (imgBytes != null) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.length);
                            admImgTutor.setImageBitmap(bitmap);
                        }

                        admNomeTutor.setText(rs.getString("nome"));
                        nomeClicadoTutor= rs.getString("nome");
                        admDescricaoTutor.setText(rs.getString("descricao"));
                        admTelefoneTutor.setText(rs.getString("telefone"));
                    }

                    if (admImgTutor.getDrawable() == null) {
                        btnAdmSelecinarFotoTutor.setAlpha(1);
                    } else {
                        btnAdmSelecinarFotoTutor.setAlpha(0);
                    }

                    funMostrarDadosTutor();
                    admEmailTutor.setEnabled(false);

                    rs.close();
                    stmt.close();
                    con.close();
                } catch (Exception e) {
                    throw new RuntimeException("Erro ao buscar detalhes do tutor", e);
                }
            }
        });

        listaGerenciarTutor.setAdapter(mainAdapter);

        etPesquisarTutor.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().isEmpty()) {
                    updateRecyclerView(); // Mostra toda a lista se não houver texto
                } else {
                    funPesquisarTutor(s.toString()); // Faz o filtro
                }
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        btAdmAlterarDadosTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAdmAlterarDadosTutor();
            }
        });

        admDeletarTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idTutorClicado == null) {
                    Toast.makeText(getActivity(), "Nenhum tutor selecionado!", Toast.LENGTH_SHORT).show();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage("Você tem certeza que deseja excluir o tutor " + nomeClicadoTutor + "?")
                            .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Confirmar"
                                    funDeletarTutor();
                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Cancelar"
                                }
                            });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });

        btVoltarAdmTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funEsconderDadosTutor();
            }
        });

       return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funEsconderDadosTutor();
        funListaTutor();
        etPesquisarTutor.setText(null);
    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    public void funListaTutor() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, email, foto, nome FROM adm_info_tutor";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdGerenciarTutor.clear();
            listaEmailGerenciarTutor.clear();
            listaFotoGerenciarTutor.clear();
            listaNomeGerenciarTutor.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                Integer id = rs.getInt("id_login");
                String email = rs.getString("email");
                byte[] fotoBytes = rs.getBytes("foto");
                String nome = rs.getString("nome");

                // Adicionar os dados nas listas
                listaIdGerenciarTutor.add(id);

                if (fotoBytes != null) {
                    // Converter a foto para Bitmap
                    Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                    // Chama o método para arredondar a imagem
                    Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                    listaFotoGerenciarTutor.add(roundedBitmap);
                } else {
                    listaFotoGerenciarTutor.add(null);
                }

                listaEmailGerenciarTutor.add(email);
                listaNomeGerenciarTutor.add(nome);
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            // Atualize o RecyclerView com os dados
            updateRecyclerView();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModels.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdGerenciarTutor.size(); i++) {
            MainModelGerenciarTutor model = new MainModelGerenciarTutor(listaIdGerenciarTutor.get(i), listaFotoGerenciarTutor.get(i), listaEmailGerenciarTutor.get(i), listaNomeGerenciarTutor.get(i));
            mainModels.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapter.notifyDataSetChanged();
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }

    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(Integer idTutor) {
        byte[] imgBytesAtual = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM adm_info_tutor WHERE id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idTutor);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imgBytesAtual;
    }

    public void funPesquisarTutor(String termo) {
        ArrayList<MainModelGerenciarTutor> listaFiltrada = new ArrayList<>();
        String filtro = termo.toLowerCase().trim();

        for (int i = 0; i < listaIdGerenciarTutor.size(); i++) {
            String nome = listaNomeGerenciarTutor.get(i).toLowerCase();
            String email = listaEmailGerenciarTutor.get(i).toLowerCase();

            if (nome.contains(filtro) || email.contains(filtro)) {
                listaFiltrada.add(new MainModelGerenciarTutor(
                        listaIdGerenciarTutor.get(i),
                        listaFotoGerenciarTutor.get(i),
                        listaEmailGerenciarTutor.get(i),
                        listaNomeGerenciarTutor.get(i)
                ));
            }
        }

        mainAdapter.atualizarLista(listaFiltrada);
    }

    public void funAdmAlterarDadosTutor() {
        String nomeTutor = admNomeTutor.getText().toString().trim();
        String telefoneTutor = admTelefoneTutor.getText().toString().trim();
        String biografiaTutor = admDescricaoTutor.getText().toString().trim();

        if (nomeTutor.isEmpty()) { admNomeTutor.setError("Campo obrigatório"); return; }

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "UPDATE tutor SET nome = ?, descricao = ?, telefone = ? WHERE id_tutor = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nomeTutor);
            stmt.setString(2, biografiaTutor);
            stmt.setString(3, telefoneTutor);
            stmt.setInt(4, idTutorClicado);
            stmt.executeUpdate();

            stmt.close();
            con.close();

            nomeClicadoTutor = nomeTutor;
            funListaTutor();

            Toast.makeText(getActivity(), "Dados atualizados com sucesso!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public void funDeletarTutor() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM login WHERE id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idTutorClicado);
            stmt.execute();

            stmt.close();
            con.close();

            funEsconderDadosTutor();
            funListaTutor();

            idTutorClicado = null;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funDesativarCampos() {
        admEmailTutor.setEnabled(false);
        admNomeTutor.setEnabled(false);
        admTelefoneTutor.setEnabled(false);
        admDescricaoTutor.setEnabled(false);
    }

    public void funAtivarCampos() {
        admEmailTutor.setEnabled(true);
        admNomeTutor.setEnabled(true);
        admTelefoneTutor.setEnabled(true);
        admDescricaoTutor.setEnabled(true);
    }

    public void funLimparCampos() {
        admEmailTutor.setText(null);
        admNomeTutor.setText(null);
        admTelefoneTutor.setText(null);
        admDescricaoTutor.setText(null);
    }

    public void funEsconderDadosTutor() {
        frameLayoutGerenciarTutor.setVisibility(GONE);
        btnAdmSelecinarFotoTutor.setVisibility(GONE);
        admImgTutor.setVisibility(GONE);
        tvAdmEmailTutor.setVisibility(GONE);
        admEmailTutor.setVisibility(GONE);
        tvAdmNomeTutor.setVisibility(GONE);
        admNomeTutor.setVisibility(GONE);
        tvAdmTelefoneTutor.setVisibility(GONE);
        admTelefoneTutor.setVisibility(GONE);
        tvAdmDesricaoTutor.setVisibility(GONE);
        admDescricaoTutor.setVisibility(GONE);
        btAdmAlterarDadosTutor.setVisibility(GONE);
        admDeletarTutor.setVisibility(GONE);
        btVoltarAdmTutor.setVisibility(GONE);
        etPesquisarTutor.setVisibility(VISIBLE);
        listaGerenciarTutor.setVisibility(VISIBLE);
    }

    public void funMostrarDadosTutor() {
        etPesquisarTutor.setVisibility(GONE);
        listaGerenciarTutor.setVisibility(GONE);
        btVoltarAdmTutor.setVisibility(VISIBLE);
        frameLayoutGerenciarTutor.setVisibility(VISIBLE);
        btnAdmSelecinarFotoTutor.setVisibility(VISIBLE);
        admImgTutor.setVisibility(VISIBLE);
        tvAdmEmailTutor.setVisibility(VISIBLE);
        admEmailTutor.setVisibility(VISIBLE);
        tvAdmNomeTutor.setVisibility(VISIBLE);
        admNomeTutor.setVisibility(VISIBLE);
        tvAdmTelefoneTutor.setVisibility(VISIBLE);
        admTelefoneTutor.setVisibility(VISIBLE);
        tvAdmDesricaoTutor.setVisibility(VISIBLE);
        admDescricaoTutor.setVisibility(VISIBLE);
        btAdmAlterarDadosTutor.setVisibility(VISIBLE);
        admDeletarTutor.setVisibility(VISIBLE);
        admNomeTutor.setError(null);
    }
}