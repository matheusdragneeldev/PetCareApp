package com.example.petcareapp.ui.mensagemPerfil;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link mensagemPerfilFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class mensagemPerfilFragment extends Fragment {

    private String emailUsuarioAtual, tipoUserAtual;
    private Integer idUsuarioAtual;
    String userId = null;

    // Executor para operações em segundo plano
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    TextView tvNomeMsg, tvDescMsg, tvTelefoneMsg, tvFuncionamentoMsg, tvEnderecoMsg, tvLogradouroMsg,
            tvBairroMsg, tvCidadeMsg, tvEstadoMsg, tvComplementoMsg, tvNumeroMsg;
    EditText nomeMsg, descricaoMsg, telefoneMsg, funcionamentoMsg, logradouroMsg, bairroMsg, numeroMsg, cidadeMsg, estadoMsg, complementoMsg;
    CircleImageView imagemPerfil;
    ProgressBar progressBar;
    ConstraintLayout mainContentLayout;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public mensagemPerfilFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment mensagemPerfilFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static mensagemPerfilFragment newInstance(String param1, String param2) {
        mensagemPerfilFragment fragment = new mensagemPerfilFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_mensagem_perfil, container, false);

        tvNomeMsg = view.findViewById(R.id.tvNomeMsg);
        tvDescMsg = view.findViewById(R.id.tvDescMsg);
        tvTelefoneMsg = view.findViewById(R.id.tvTelefoneMsg);
        tvFuncionamentoMsg = view.findViewById(R.id.tvFuncionamentoMsg);
        tvEnderecoMsg = view.findViewById(R.id.tvEnderecoMsg);
        tvLogradouroMsg = view.findViewById(R.id.tvLogradouroMsg);
        tvBairroMsg = view.findViewById(R.id.tvBairroMsg);
        tvCidadeMsg = view.findViewById(R.id.tvCidadeMsg);
        tvEstadoMsg = view.findViewById(R.id.tvEstadoMsg);
        tvComplementoMsg = view.findViewById(R.id.tvComplementoMsg);
        tvNumeroMsg = view.findViewById(R.id.tvNumeroMsg);
        nomeMsg = view.findViewById(R.id.nomeMsg);
        descricaoMsg = view.findViewById(R.id.descricaoMsg);
        telefoneMsg = view.findViewById(R.id.telefoneMsg);
        funcionamentoMsg = view.findViewById(R.id.funcionamentoMsg);
        logradouroMsg = view.findViewById(R.id.logradouroMsg);
        bairroMsg = view.findViewById(R.id.bairroMsg);
        numeroMsg = view.findViewById(R.id.numeroMsg);
        cidadeMsg = view.findViewById(R.id.cidadeMsg);
        estadoMsg = view.findViewById(R.id.estadoMsg);
        complementoMsg = view.findViewById(R.id.complementoMsg);
        imagemPerfil = view.findViewById(R.id.imagemPerfil);
        progressBar = view.findViewById(R.id.progressBar);
        mainContentLayout = view.findViewById(R.id.mainContentLayout);

        nomeMsg.setEnabled(false);
        descricaoMsg.setEnabled(false);
        telefoneMsg.setEnabled(false);
        funcionamentoMsg.setEnabled(false);
        logradouroMsg.setEnabled(false);
        bairroMsg.setEnabled(false);
        numeroMsg.setEnabled(false);
        cidadeMsg.setEnabled(false);
        estadoMsg.setEnabled(false);
        complementoMsg.setEnabled(false);

        // Pega o "pacote" (Bundle) de argumentos que foi anexado
        Bundle args = getArguments();

        // Importante para verificar se os argumentos não são nulos
        if (args != null) {
            // Pega o dado de dentro do Bundle usando a MESMA chave
            userId = args.getString("KEY_USER_ID");
        }

        // Mostra uma mensagem de erro, pois o ID não foi recebido
        if (userId == null) {
            Toast.makeText(getContext(), "Erro: Não foi possível carregar o perfil.", Toast.LENGTH_SHORT).show();
        }

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // --- MUDANÇA 1: Prepara a tela para o carregamento ---
        // Mostra o ProgressBar e esconde o conteúdo principal IMEDIATAMENTE.
        if (progressBar != null) progressBar.setVisibility(VISIBLE);
        if (mainContentLayout != null) mainContentLayout.setVisibility(GONE);

        // Inicia a busca do usuário atual e do perfil em uma thread separada
        executor.execute(() -> {
            String emailUsuarioAtual = (FirebaseAuth.getInstance().getCurrentUser() != null)
                    ? FirebaseAuth.getInstance().getCurrentUser().getEmail()
                    : null;

            if (emailUsuarioAtual == null) {
                handler.post(() -> {
                    Toast.makeText(getContext(), "Erro: Usuário não autenticado.", Toast.LENGTH_SHORT).show();
                    // Garante que o ProgressBar suma em caso de erro
                    if (progressBar != null) progressBar.setVisibility(GONE);
                });
                return;
            }

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT tipo_user FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    tipoUserAtual = rs.getString("tipo_user");

                    handler.post(() -> {
                        // --- MUDANÇA 2: Configura a UI ANTES de mostrá-la ---
                        // Decide qual layout e busca de perfil chamar com base no tipo de usuário
                        if ("Clinica".equals(tipoUserAtual)) {
                            funLayoutTutor();
                            funBuscarPerfilTutor();
                        } else {
                            funBuscarPerfilClinica();
                        }

                        // --- MUDANÇA 3: Mostra o conteúdo já pronto ---
                        // Agora que a UI está configurada, esconde o ProgressBar e mostra o conteúdo.
                        if (progressBar != null) progressBar.setVisibility(GONE);
                        if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                    });
                } else {
                    handler.post(() -> {
                        Toast.makeText(getContext(), "Erro: Tipo de usuário não encontrado.", Toast.LENGTH_SHORT).show();
                        if (progressBar != null) progressBar.setVisibility(GONE); // Esconde em caso de erro
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> {
                    Toast.makeText(getContext(), "Erro ao buscar dados.", Toast.LENGTH_LONG).show();
                    if (progressBar != null) progressBar.setVisibility(GONE); // Esconde em caso de erro
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Garante que o ExecutorService seja desligado quando o Fragment for destruído.
        // Isso libera os recursos da thread e evita vazamentos de memória.
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow(); // Tenta parar todas as tarefas em execução e as que estão na fila.
        }
    }

    public void funBuscarPerfilTutor() {
        // Usando o 'executor' que já é membro da classe
        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT foto, nome, descricao FROM tutor WHERE id_tutor = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, userId);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    // Apenas pegamos os dados brutos. Sem criar Bitmap aqui!
                    final byte[] fotoBytes = rs.getBytes("foto");
                    final String nome = rs.getString("nome");
                    final String descricao = rs.getString("descricao");

                    // Enviamos os dados para a thread da UI
                    handler.post(() -> {
                        // Preenche os campos de texto
                        nomeMsg.setText(nome);
                        descricaoMsg.setText(descricao);

                        // Deixamos o Glide fazer todo o trabalho pesado!
                        Glide.with(requireContext())
                                .load(fotoBytes) // Carrega os bytes diretamente
                                .error(R.drawable.user) // Imagem se fotoBytes for nulo ou der erro
                                .circleCrop() // Arredonda a imagem
                                .into(imagemPerfil); // Onde a imagem será exibida
                    });
                } else {
                    handler.post(() -> Toast.makeText(getContext(), "Perfil de tutor não encontrado.", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(getContext(), "Erro ao buscar perfil do tutor.", Toast.LENGTH_LONG).show());
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funBuscarPerfilClinica() {
        // Usando o 'executor' que já é membro da classe
        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM perfil_info_clinica WHERE id_clinica = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, userId);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    // Apenas pegamos os dados brutos.
                    final byte[] fotoBytes = rs.getBytes("foto");
                    final String nome = rs.getString("nome");
                    final String descricao = rs.getString("descricao");
                    final String telefone = rs.getString("telefone");
                    final String funcionamento = rs.getString("funcionamento");
                    final String logradouro = rs.getString("logradouro");
                    final String bairro = rs.getString("bairro");
                    final String numero = rs.getString("numero");
                    final String complemento = rs.getString("complemento");
                    final String cidade = rs.getString("cidade");
                    final String estado = rs.getString("estado");

                    // Enviamos os dados para a thread da UI
                    handler.post(() -> {
                        // Preenche todos os campos de texto
                        nomeMsg.setText(nome);
                        descricaoMsg.setText(descricao);
                        telefoneMsg.setText(telefone);
                        funcionamentoMsg.setText(funcionamento);
                        logradouroMsg.setText(logradouro);
                        bairroMsg.setText(bairro);
                        numeroMsg.setText(numero);
                        complementoMsg.setText(complemento);
                        cidadeMsg.setText(cidade);
                        estadoMsg.setText(estado);

                        // Deixamos o Glide fazer todo o trabalho pesado!
                        Glide.with(requireContext())
                                .load(fotoBytes)
                                .error(R.drawable.petshop)
                                .transform(new CircleCrop()) // Mantemos o corte de círculo, que é importante
                                .into(imagemPerfil);
                    });
                } else {
                    handler.post(() -> Toast.makeText(getContext(), "Perfil de clínica não encontrado.", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(getContext(), "Erro ao buscar perfil da clínica.", Toast.LENGTH_LONG).show());
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funLayoutTutor() {
        tvTelefoneMsg.setVisibility(GONE);
        telefoneMsg.setVisibility(GONE);
        tvFuncionamentoMsg.setVisibility(GONE);
        funcionamentoMsg.setVisibility(GONE);
        tvEnderecoMsg.setVisibility(GONE);
        tvLogradouroMsg.setVisibility(GONE);
        logradouroMsg.setVisibility(GONE);
        tvBairroMsg.setVisibility(GONE);
        bairroMsg.setVisibility(GONE);
        tvCidadeMsg.setVisibility(GONE);
        cidadeMsg.setVisibility(GONE);
        tvEstadoMsg.setVisibility(GONE);
        estadoMsg.setVisibility(GONE);
        tvComplementoMsg.setVisibility(GONE);
        complementoMsg.setVisibility(GONE);
        tvNumeroMsg.setVisibility(GONE);
        numeroMsg.setVisibility(GONE);
    }

}