package com.example.petcareapp;

// Imports necessários para as novas funcionalidades
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.util.Log;
import androidx.core.content.ContextCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

// Removida a importação do fragmento que não era usada aqui

public class NotificationHelper {

    public static final String CHANNEL_ID = "new_message_channel";
    private static final String CHANNEL_NAME = "Novas Mensagens";
    private static final String CHANNEL_DESC = "Notificações para novas mensagens recebidas";

    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription(CHANNEL_DESC);

            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    public static void showNewMessageNotification(Context context, String sender, String message) {

        // --- PASSO 1: LER O TIPO DE USUÁRIO DO SHAREDPREFERENCES ---
        SharedPreferences sharedPref = context.getSharedPreferences("PetCarePrefs", Context.MODE_PRIVATE);
        // Usa "Tutor" como padrão para o caso de não encontrar nada (um fallback seguro)
        String userType = sharedPref.getString("USER_TYPE", "Tutor");
        Log.d("NotificationHelper", "Tipo de usuário lido: " + userType);


        // --- PASSO 2: DECIDIR QUAL ACTIVITY ABRIR COM BASE NO TIPO DE USUÁRIO ---
        Intent intent;
        switch (userType) {
            case "Clinica":
                intent = new Intent(context, MainClinicaActivity.class);
                break;
            case "ADM":
                intent = new Intent(context, MainAdmActivity.class);
                break;
            case "Tutor":
            default: // Caso padrão ou se o tipo for "Tutor"
                intent = new Intent(context, MainActivity.class);
                break;
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);


        // --- PASSO 3: CONSTRUIR A NOTIFICAÇÃO ---
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification_message) // Lembre-se que este ícone precisa existir em res/drawable
                .setContentTitle("Nova mensagem de " + sender)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent) // Define a ação de toque
                .setAutoCancel(true); // Remove a notificação quando o usuário toca nela


        // --- PASSO 4: EXIBIR A NOTIFICAÇÃO (COM VERIFICAÇÃO DE PERMISSÃO) ---
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            int notificationId = (int) System.currentTimeMillis();
            notificationManager.notify(notificationId, builder.build());
        } else {
            Log.w("NotificationHelper", "Não foi possível exibir a notificação, permissão negada.");
        }
    }

    public static void showVaccineReminderNotification(Context context, String petName, String vaccineName) {

        // Como só tutores têm vacina, o intent sempre abrirá a MainActivity do Tutor.
        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Texto da notificação ajustado para o seu exemplo
        String title = "Lembrete de Vacina 💉";
        String text = "A vacina de " + vaccineName + " do seu PET " + petName + " está próxima.";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_vaccine_reminder) // ícone
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text + " Verifique a carteirinha de vacinação."))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            int notificationId = (petName + vaccineName).hashCode();
            notificationManager.notify(notificationId, builder.build());
        }
    }

}