package com.example.petcareapp;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.Toast;

import com.example.petcareapp.ui.seguranca.segurancaFragment;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.example.petcareapp.databinding.ActivityMainBinding;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;

    // Declara o lançador para o pedido de permissão
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // Permissão concedida. Você pode querer habilitar alguma funcionalidade
                    // relacionada a notificações aqui.
                } else {
                    // Permissão negada. Informe ao usuário que ele não receberá notificações.
                    // Você pode mostrar um Toast ou um Snackbar.
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        NotificationHelper.createNotificationChannel(this); // Chame aqui
        askNotificationPermission();

        /* Apenas para testar a notificação das vacinas
        Button btnTestarNotificacao = findViewById(R.id.btnTestarNotificacao);

        btnTestarNotificacao.setOnClickListener(v -> {
            // Cria uma requisição ÚNICA para o seu worker, em vez de uma periódica.
            OneTimeWorkRequest testeRequest = new OneTimeWorkRequest.Builder(VaccineReminderWorker.class)
                    .build();

            // Envia a requisição para a fila do WorkManager para ser executada o mais rápido possível.
            WorkManager.getInstance(this).enqueue(testeRequest);

            // Mostra uma mensagem para saber que o teste foi iniciado.
            Toast.makeText(this, "Teste de notificação iniciado...", Toast.LENGTH_SHORT).show();
        });
         */

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_perfil_tutor, R.id.nav_pet, R.id.nav_cartao_vacina, R.id.nav_doenca,R.id.nav_guia,
                R.id.nav_campanha, R.id.nav_mensagem, R.id.nav_buscar_clinica, R.id.nav_feedback, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) { //Ação do Menu
    // Se o item do menu for selecionado, navegue para o fragmento de configurações

        if (item.getItemId() == R.id.action_sair) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            // Finaliza telas anteriores, impedindo de voltar após o logout
            //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }

        if (item.getItemId() == R.id.action_seguranca) {
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main); //Nav MainActivity
            // Navegue para o fragmento desejado
            navController.navigate(R.id.nav_seguranca); // Nav da Tela
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private void askNotificationPermission() {
        // Esta verificação só é necessária para Android 13 (TIRAMISU) ou superior
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED) {
                // A permissão já foi concedida.
            } else {
                // A permissão ainda não foi concedida, então solicite-a.
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }
}