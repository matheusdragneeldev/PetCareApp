package com.example.petcareapp.ui.perfilAdm;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link perfilAdmFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class perfilAdmFragment extends Fragment {

    String emailUsuarioAtual, idAdm;
    Integer idUsuarioAtual;

    EditText etNomeAdm;
    Button btSalvarAdm, btnSelecionarFoto;
    ImageView imagemAdm;

    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public perfilAdmFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment perfilAdmFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static perfilAdmFragment newInstance(String param1, String param2) {
        perfilAdmFragment fragment = new perfilAdmFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                imagemAdm.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                                // Verificando se a ImageView está vazia
                                Drawable drawable = imagemAdm.getDrawable();

                                if (drawable != null) {
                                    btnSelecionarFoto.setAlpha(0);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_perfil_adm, container, false);

        etNomeAdm = view.findViewById(R.id.etNomeAdm);
        btSalvarAdm = view.findViewById(R.id.btSalvarAdm);
        btnSelecionarFoto = view.findViewById(R.id.btnSelecionarFoto);
        imagemAdm = view.findViewById(R.id.imagemAdm);

        btSalvarAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeAdm = etNomeAdm.getText().toString().trim();

                if(nomeAdm.isEmpty()) {
                    etNomeAdm.setError("campo obrigatório");
                } else {
                    funAtualizarAdm();
                }

            }
        });

        btnSelecionarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funSelecionarFoto();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funBuscarAdm();
        etNomeAdm.setError(null);
    }

    public void funBuscarAdm() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM adm WHERE fk_id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            Drawable drawable = imagemAdm.getDrawable();

            while(rs.next()) {
                byte[] fotoBytes = rs.getBytes("foto");

                if (fotoBytes != null) {
                    btnSelecionarFoto.setAlpha(0);

                    //Converter a foto para Bitmap
                    Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0 , fotoBytes.length);

                    //Chama o metodo para arredondar a foto;
                    Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                    imagemAdm.setImageBitmap(roundedBitmap);
                }

                etNomeAdm.setText(rs.getString("nome"));
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }


    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(String idAdm) {
        byte[] imgBytesAtual = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM adm WHERE id_adm = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imgBytesAtual;
    }

    public void funAtualizarAdm() {
        String nome = etNomeAdm.getText().toString().trim();

        // Se a imagem foi alterada
        byte[] imgBytes = null;
        if (imageChanged) {
            // Se uma nova imagem foi selecionada, converte para bytes
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            selectedBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            imgBytes = byteArrayOutputStream.toByteArray();
        } else {
            // Caso a imagem não tenha sido alterada, recupere a imagem existente do banco de dados
            imgBytes = getImgBytesFromDatabase(idAdm);  // Supondo que você tenha um método para recuperar a imagem do banco
        }

        // Atualiza o banco de dados
        try {
            Connection con = ConexaoMysql.conectar();
            String sql;
            PreparedStatement stmt;

            if (imageChanged) {
                // Atualiza com a nova foto, caso tenha sido alterada
                sql = "update adm set foto = ?, nome = ? where id_adm = ?;";
                stmt = con.prepareStatement(sql);

                stmt.setBytes(1,imgBytes);
                stmt.setString(2,nome);
                stmt.setInt(3,idUsuarioAtual);
            } else {
                // Se a imagem não foi alterada, atualiza sem tocar na foto
                sql = "update adm set nome = ? where id_adm = ?;";
                stmt = con.prepareStatement(sql);

                stmt.setString(1,nome);
                stmt.setInt(2,idUsuarioAtual);
            }

            stmt.executeUpdate();

            imageChanged = false;

            stmt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

}