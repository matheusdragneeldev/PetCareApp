package com.example.petcareapp.util;

public final class FragmentArgs {
    // Construtor privado para que a classe não possa ser instanciada
    private FragmentArgs() {}

    /** Chave para passar o ID do usuário entre fragments. */
    public static final String KEY_USER_ID = "USER_ID_KEY";
}