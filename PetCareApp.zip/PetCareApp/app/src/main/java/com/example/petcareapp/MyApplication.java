package com.example.petcareapp;

import android.app.Application;

import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        scheduleVaccineReminder();
    }

    private void scheduleVaccineReminder() {
        // Define restrições (ex: só rodar quando tiver internet)
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        // Cria uma requisição periódica para rodar UMA VEZ POR DIA
        PeriodicWorkRequest reminderRequest =
                new PeriodicWorkRequest.Builder(VaccineReminderWorker.class, 1, TimeUnit.DAYS)
                        .setConstraints(constraints)
                        .build();

        // Agenda a tarefa de forma única, para não criar duplicatas
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "vaccine_reminder_work",
                androidx.work.ExistingPeriodicWorkPolicy.KEEP, // Mantém a tarefa se já existir
                reminderRequest
        );
    }
}