package com.example.petcareapp.ui.mensagem;

public class MainModelMsg {
    private Integer idRemetente;
    private Integer idDestinatario;
    private String nomeRemetente;
    private String listaMensagem;

    public MainModelMsg(Integer idRemetente, Integer idDestinatario, String nomeRemetente, String listaMensagem) {
        this.idRemetente = idRemetente;
        this.idDestinatario = idDestinatario;
        this.nomeRemetente = nomeRemetente;
        this.listaMensagem = listaMensagem;
    }

    public Integer getIdRemetente() {
        return idRemetente;
    }

    public Integer getIdDestinatario() {
        return idDestinatario;
    }

    public String getNomeRemetente() {
        return nomeRemetente;
    }

    public String getListaMensagem() {
        return listaMensagem;
    }
}