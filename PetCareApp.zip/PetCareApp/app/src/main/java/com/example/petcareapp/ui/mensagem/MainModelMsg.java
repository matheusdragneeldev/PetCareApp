package com.example.petcareapp.ui.mensagem;

import java.util.Objects;

public class MainModelMsg {

    // --- MUDANÇA 1: Adicionar o ID único da mensagem ---
    private Integer idMensagem;

    private Integer idRemetente;
    private Integer idDestinatario;
    private String nomeRemetente;
    private String listaMensagem;

    // --- MUDANÇA 2: Atualizar o construtor para incluir o idMensagem ---
    public MainModelMsg(Integer idMensagem, Integer idRemetente, Integer idDestinatario, String nomeRemetente, String listaMensagem) {
        this.idMensagem = idMensagem;
        this.idRemetente = idRemetente;
        this.idDestinatario = idDestinatario;
        this.nomeRemetente = nomeRemetente;
        this.listaMensagem = listaMensagem;
    }

    // --- MUDANÇA 3: Adicionar o getter para o novo campo ---
    public Integer getIdMensagem() {
        return idMensagem;
    }

    // Getters existentes (continuam iguais)
    public Integer getIdRemetente() {
        return idRemetente;
    }

    public Integer getIdDestinatario() {
        return idDestinatario;
    }

    public String getNomeRemetente() {
        return nomeRemetente;
    }

    public String getListaMensagem() {
        return listaMensagem;
    }

    // --- MUDANÇA 4: Corrigir completamente o método equals() ---
    // Ele agora compara todos os campos que existem NESTA classe.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MainModelMsg that = (MainModelMsg) o;
        return Objects.equals(idMensagem, that.idMensagem) &&
                Objects.equals(idRemetente, that.idRemetente) &&
                Objects.equals(idDestinatario, that.idDestinatario) &&
                Objects.equals(nomeRemetente, that.nomeRemetente) &&
                Objects.equals(listaMensagem, that.listaMensagem);
    }

    // --- MUDANÇA 5: Corrigir completamente o método hashCode() ---
    // Ele agora usa os mesmos campos do equals() para gerar o hash.
    @Override
    public int hashCode() {
        return Objects.hash(idMensagem, idRemetente, idDestinatario, nomeRemetente, listaMensagem);
    }
}