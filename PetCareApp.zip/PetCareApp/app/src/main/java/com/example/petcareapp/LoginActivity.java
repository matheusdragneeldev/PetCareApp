package com.example.petcareapp;

import static android.content.ContentValues.TAG;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.content.Context; // NOVO: Import necessário
import android.content.Intent;
import android.content.SharedPreferences; // NOVO: Import necessário
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginActivity extends AppCompatActivity {

    private final java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newSingleThreadExecutor();
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());

    String emailUsuarioAtual,tipoUsuarioAtual;

    EditText loginEmail, loginSenha;
    Button btLoginEntrar;
    TextView telaLoginCadastrar, telaRecuperarSenha;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        funIniciarComponentes();

        btLoginEntrar.setOnClickListener(v -> {
            String email = loginEmail.getText().toString().trim();
            String senha = loginSenha.getText().toString().trim();

            if (email.isEmpty() || senha.isEmpty()) {
                funMostrarSnackbar(v, 1); // Mostra erro de campos vazios
            } else {
                autenticarUsuario(v);
            }
        });

        telaLoginCadastrar.setOnClickListener(v -> {
            Intent tcl = new Intent(LoginActivity.this, CadastrarLoginActivity.class);
            startActivity(tcl);
            finish();
        });

        telaRecuperarSenha.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RecuperarSenhaActivity.class);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();
        if (usuarioAtual != null) {
            progressBar.setVisibility(View.VISIBLE);
            usuarioAtual.reload().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    emailUsuarioAtual = usuarioAtual.getEmail();
                    verificarTipoUsuarioERedirecionar(usuarioAtual);
                } else {
                    progressBar.setVisibility(View.GONE);
                    Log.e(TAG, "Erro ao recarregar usuário.", task.getException());
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }

    private void autenticarUsuario(View v) {
        String email = loginEmail.getText().toString().trim();
        String senha = loginSenha.getText().toString().trim();

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, senha)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        progressBar.setVisibility(VISIBLE);
                        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();
                        if (usuarioAtual != null) {
                            usuarioAtual.reload().addOnCompleteListener(reloadTask -> {
                                if (reloadTask.isSuccessful()) {
                                    emailUsuarioAtual = usuarioAtual.getEmail();
                                    verificarTipoUsuarioERedirecionar(usuarioAtual);
                                } else {
                                    progressBar.setVisibility(View.GONE);
                                    Log.e(TAG, "Erro ao recarregar usuário após login.", reloadTask.getException());
                                }
                            });
                        }
                    } else {
                        try {
                            throw task.getException();
                        } catch (FirebaseAuthInvalidCredentialsException e) {
                            funMostrarSnackbar(v, 1);
                        } catch (Exception e) {
                            funMostrarSnackbar(v, 0);
                        }
                    }
                });
    }

    private void verificarTipoUsuarioERedirecionar(FirebaseUser usuarioAtual) {
        executor.execute(() -> {
            // Renomeei a variável para não confundir com a da classe
            String tipoUsuarioLocal = null;

            try (Connection con = ConexaoMysql.conectar();
                 PreparedStatement stmt = con.prepareStatement("SELECT tipo_user FROM login WHERE email = ?")) {

                stmt.setString(1, usuarioAtual.getEmail());
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    tipoUsuarioLocal = rs.getString("tipo_user");
                }
                // O try-with-resources fecha 'rs' automaticamente se declarado nele, mas como não está, fechamos manualmente.
                if(rs != null) rs.close();

            } catch (Exception e) {
                e.printStackTrace();
                // Em caso de erro de banco, também informe o usuário
                handler.post(() -> {
                    progressBar.setVisibility(GONE);
                    Toast.makeText(LoginActivity.this, "Erro de conexão. Tente novamente.", Toast.LENGTH_SHORT).show();
                });
                return; // Sai da execução do background
            }

            // Passa a variável local final para o handler
            final String finalTipoUsuario = tipoUsuarioLocal;

            handler.post(() -> {
                progressBar.setVisibility(GONE);
                if (finalTipoUsuario != null) {
                    // Se encontrou o tipo de usuário, salva e redireciona
                    tipoUsuarioAtual = finalTipoUsuario; // Atualiza a variável da classe se necessário
                    funSalvarTipoUsuario(finalTipoUsuario);

                    Intent intent = null;
                    switch (finalTipoUsuario) {
                        case "Tutor":
                            intent = new Intent(LoginActivity.this, MainActivity.class);
                            break;
                        case "Clinica":
                            intent = new Intent(LoginActivity.this, MainClinicaActivity.class);
                            break;
                        case "ADM":
                            intent = new Intent(LoginActivity.this, MainAdmActivity.class);
                            break;
                    }
                    if (intent != null) {
                        startActivity(intent);
                        finish();
                    }
                } else {
                    // --- TRATAMENTO DE ERRO ADICIONADO ---
                    // Se o login do Firebase deu certo, mas o usuário não existe no seu banco
                    Toast.makeText(LoginActivity.this, "Usuário não encontrado em nossos registros.", Toast.LENGTH_LONG).show();
                    FirebaseAuth.getInstance().signOut(); // Desloga do Firebase para evitar inconsistência
                }
            });
        });
    }

    // NOVO: Função para salvar o tipo de usuário no SharedPreferences
    private void funSalvarTipoUsuario(String userType) {
        SharedPreferences sharedPref = getSharedPreferences("PetCarePrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("USER_TYPE", userType);
        editor.apply();
        Log.d(TAG, "Tipo de usuário '" + userType + "' salvo no SharedPreferences.");
    }

    public void funMostrarSnackbar(View v, int indice) {
        String[] mensagens = {"Ocorreu um erro ao tentar realizar o login. Tente novamente",
                "E-mail ou senha incorretos"};

        Snackbar snackbar = Snackbar.make(v, mensagens[indice], Snackbar.LENGTH_LONG);
        snackbar.setBackgroundTint(Color.BLACK);
        snackbar.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public void funIniciarComponentes() {
        loginEmail = findViewById(R.id.loginEmail);
        loginSenha = findViewById(R.id.loginSenha);
        btLoginEntrar = findViewById(R.id.btLoginEntrar);
        telaLoginCadastrar = findViewById(R.id.telaLoginCadastrar);
        telaRecuperarSenha = findViewById(R.id.telaRecuperarSenha);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(GONE);
    }
}