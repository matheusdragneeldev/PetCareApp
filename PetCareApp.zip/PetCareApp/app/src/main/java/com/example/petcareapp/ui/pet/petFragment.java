package com.example.petcareapp.ui.pet;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_LONG;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.cartaoVacina.cartaoVacinaFragment;
import com.google.firebase.auth.FirebaseAuth;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.text.ParseException;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link petFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class petFragment extends Fragment {

    String emailUsuarioAtual, nomePetClicado;
    String ultimaEspecieSelecionada = "";
    Integer idUsuarioAtual, idPetClicado;
    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada
    boolean verificarPetIsNull = false;
    boolean primeiraSelecaoSpinner = true; // Flag para ignorar primeira seleção do spinner quando ele e carregado
    boolean listaPetClick = false; // Flag para mostrar/esconder os botões para salvar/atualizar PET

    EditText nomePet, especiePet, racaPet, corPet, pesoPet, descricaoPet, dtNascimentoPet;
    TextView textFiltrarEspecie, countTextDescPet, tvNomePet, tvEspeciePet, tvRacaPet, tvCorPet, tvPesoPet, tvPortePet, tvSexoPet, tvBioPet;
    Spinner portePet, sexoPet, filtrarEspecie;
    Button btAlterarPet, btSelecionarFoto, btAtualizarPet, btAddNovoPet, btSalvarNovoPet, btAddPrimeiroPet, btDeletarPet;
    ImageButton btVoltarListaPet;
    ImageView imgPet;
    RecyclerView listaPets;
    LinearLayout linearLayout4;

    ArrayList<String> listaIdPet = new ArrayList<>();
    ArrayList<String> listaNomePet = new ArrayList<>();
    ArrayList<Bitmap> listaFotoPet = new ArrayList<>();
    ArrayList<MainModel> mainModels = new ArrayList<>();

    MainAdapter mainAdapter;

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public petFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment petFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static petFragment newInstance(String param1, String param2) {
        petFragment fragment = new petFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                   funMostrarLayoutAddPet();

                    if(!verificarPetIsNull) {
                        funMostrarPrimeiroLayout();
                    }

                    /*// Ajusta os botões com base no valor de btSelecionarFoto.getAlpha()
                    if (btSelecionarFoto.getAlpha() == 1) {
                        btSalvarNovoPet.setVisibility(VISIBLE);
                        btAtualizarPet.setVisibility(GONE);
                    } else if (btSelecionarFoto.getAlpha() == 0) {
                        btSalvarNovoPet.setVisibility(GONE);
                        btAtualizarPet.setVisibility(VISIBLE);
                    }

                     */

                    if (listaPetClick) {
                        btSalvarNovoPet.setVisibility(GONE);
                        btAtualizarPet.setVisibility(VISIBLE);
                        btDeletarPet.setVisibility(VISIBLE);
                    } else if (!listaPetClick) {
                        btAtualizarPet.setVisibility(GONE);
                        btDeletarPet.setVisibility(GONE);
                        btSalvarNovoPet.setVisibility(VISIBLE);
                    }

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                imgPet.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                                if (btSelecionarFoto.getAlpha() == 0) {
                                    btSalvarNovoPet.setVisibility(GONE);
                                    btAtualizarPet.setVisibility(VISIBLE);
                                } else if (btSelecionarFoto.getAlpha() == 1) {
                                    // Esconde o botão de selecionar a foto
                                    btSelecionarFoto.setAlpha(0);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pet, container, false);

        nomePet = view.findViewById(R.id.nomePet);
        especiePet = view.findViewById(R.id.especiePet);
        racaPet = view.findViewById(R.id.racaPet);
        corPet = view.findViewById(R.id.corPet);
        pesoPet = view.findViewById(R.id.pesoPet);
        descricaoPet = view.findViewById(R.id.descricaoPet);
        portePet = view.findViewById(R.id.portePet);
        sexoPet = view.findViewById(R.id.sexoPet);
        imgPet = view.findViewById(R.id.imgPet);
        btSelecionarFoto = view.findViewById(R.id.btSelecionarFoto);
        btAlterarPet = view.findViewById(R.id.btAlterarPet);
        btAtualizarPet = view.findViewById(R.id.btAtualizarPet);
        btAddNovoPet = view.findViewById(R.id.btAddNovoPet);
        listaPets = view.findViewById(R.id.listaPets);
        btSalvarNovoPet = view.findViewById(R.id.btSalvarNovoPet);
        filtrarEspecie = view.findViewById(R.id.filtrarEspecie);
        textFiltrarEspecie = view.findViewById(R.id.textFiltrarEspecie);
        btAddPrimeiroPet = view.findViewById(R.id.btAddPrimeiroPet);
        linearLayout4 = view.findViewById(R.id.linearLayout4);
        btDeletarPet = view.findViewById(R.id.btDeletarPet);
        countTextDescPet = view.findViewById(R.id.countTextDescPet);
        dtNascimentoPet = view.findViewById(R.id.dtNascimentoPet);
        tvNomePet = view.findViewById(R.id.tvNomePet);
        tvCorPet = view.findViewById(R.id.tvCorPet);
        tvEspeciePet = view.findViewById(R.id.tvEspeciePet);
        tvRacaPet = view.findViewById(R.id.tvRacaPet);
        tvSexoPet = view.findViewById(R.id.tvSexoPet);
        tvPortePet = view.findViewById(R.id.tvPortePet);
        tvPesoPet = view.findViewById(R.id.tvPesoPet);
        tvBioPet = view.findViewById(R.id.tvBioPet);
        linearLayout4 = view.findViewById(R.id.linearLayout4);
        btVoltarListaPet = view.findViewById(R.id.btVoltarListaPet);

        // Aplica o filtro de validação
        dtNascimentoPet.setFilters(new InputFilter[]{ new petFragment.DateInputFilter() });

        dtNascimentoPet.addTextChangedListener(new TextWatcher() {
            private boolean isUpdating;

            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isUpdating) return;

                // Remove caracteres não numéricos
                String clean = s.toString().replaceAll("[^\\d]", "");
                if (clean.length() > 8) clean = clean.substring(0, 8);

                StringBuilder out = new StringBuilder();
                for (int i = 0; i < clean.length(); i++) {
                    out.append(clean.charAt(i));
                    if ((i == 1 || i == 3) && i != clean.length() - 1) out.append('/');
                }

                isUpdating = true;
                dtNascimentoPet.setText(out.toString());
                dtNascimentoPet.setSelection(out.length());
                isUpdating = false;
            }
        });

        // Contador de caracteres
        descricaoPet.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int currentLength = s.length();
                countTextDescPet.setText(currentLength + "/250");
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.HORIZONTAL,false
        );
        listaPets.setLayoutManager(layoutManager);
        listaPets.setItemAnimator(new DefaultItemAnimator());

        // Inicia MainAdapter
        mainAdapter = new MainAdapter(getActivity(),mainModels);
        // Set MainAdapter para listaPets

        mainAdapter = new MainAdapter(getActivity(), mainModels, new MainAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(MainModel model) {
                try {
                    listaPetClick = true;

                    // Obtenha o nome do pet do modelo
                    idPetClicado = Integer.valueOf(model.getListaIdPet());

                    Connection con = ConexaoMysql.conectar();
                    String sql = "SELECT * FROM pet WHERE id_pet = ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idPetClicado);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        idPetClicado = Integer.valueOf(rs.getString("id_pet"));
                        nomePet.setText(rs.getString("nome"));
                        nomePetClicado = rs.getString("nome");
                        especiePet.setText(rs.getString("especie"));
                        racaPet.setText(rs.getString("raca"));
                        corPet.setText(rs.getString("cor"));
                        pesoPet.setText(rs.getString("peso"));
                        descricaoPet.setText(rs.getString("descricao"));

                        Date dataNascimento = rs.getDate("dt_nascimento");
                        if (dataNascimento != null) {
                            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                            String dataFormatada = formato.format(dataNascimento);
                            dtNascimentoPet.setText(dataFormatada);
                        }

                        // Preenche a imagem
                        byte[] imgBytes = rs.getBytes("foto");
                        if (imgBytes != null) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.length);
                            imgPet.setImageBitmap(bitmap);
                        }

                        String sexo = rs.getString("sexo");
                        if ("Macho".equals(sexo)) {
                            sexoPet.setSelection(0);  // Assume que "Macho" está na posição 0
                        } else if ("Fêmea".equals(sexo)) {
                            sexoPet.setSelection(1);  // Assume que "Fêmea" está na posição 1
                        }

                        String porte = rs.getString("porte");
                        if ("Pequeno".equals(porte)) {
                            portePet.setSelection(0);
                        } else if ("Médio".equals(porte)) {
                            portePet.setSelection(1);
                        } else if ("Grande".equals(porte)) {
                            portePet.setSelection(2);
                        }

                        if (imgPet.getVisibility() == GONE) {
                            funMostrarLayoutPet();
                            //funMostrarLayout();
                            btDeletarPet.setVisibility(VISIBLE);
                        }

                    }

                    btSelecionarFoto.setAlpha(0);
                    btDeletarPet.setVisibility(VISIBLE);

                    funDesativarCampos();

                    rs.close();
                    stmt.close();
                    con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                    // Lança uma exceção personalizada ou trata o erro conforme necessário
                    throw new RuntimeException("Erro ao buscar detalhes do pet", e);
                }
            }
        });

        listaPets.setAdapter(mainAdapter);
        funDesativarCampos();

        btSelecionarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funSelecionarFoto();
            }
        });

        btAlterarPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCampos();
            }
        });

        btAtualizarPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtualizarPet();
                // idPetClicado = null; // Desativei por questão de bug, após melhoria
            }
        });

        btAddNovoPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listaPetClick = false;
                imgPet.setImageDrawable(null);
                funPetIsNull();
                idPetClicado = null;
                funMostrarLayoutAddPet();
                funLimparCamposAddPet();
            }
        });

        btAddPrimeiroPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funMostrarPrimeiroLayout();

                nomePet.setEnabled(true);
                corPet.setEnabled(true);
                pesoPet.setEnabled(true);
                especiePet.setEnabled(true);
                racaPet.setEnabled(true);
                portePet.setEnabled(true);
                sexoPet.setEnabled(true);
                descricaoPet.setEnabled(true);
                dtNascimentoPet.setEnabled(true);
                btSelecionarFoto.setEnabled(true);

                nomePet.setText(null);
                corPet.setText(null);
                pesoPet.setText(null);
                especiePet.setText(null);
                racaPet.setText(null);
                portePet.setSelection(0);;
                sexoPet.setSelection(0);
                descricaoPet.setText(null);
                dtNascimentoPet.setText(null);

                idPetClicado = null;
            }
        });

        btSalvarNovoPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funCadastrarPet();
            }
        });

        filtrarEspecie.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (primeiraSelecaoSpinner) {
                    primeiraSelecaoSpinner = false; // ignora a primeira seleção
                    return;
                }

                String especieSelecionada = filtrarEspecie.getSelectedItem().toString();

                // Verifica se a espécie selecionada é diferente da última seleção
                if (!especieSelecionada.equals(ultimaEspecieSelecionada)) {
                    ultimaEspecieSelecionada = especieSelecionada;

                    try {
                        Connection con = ConexaoMysql.conectar();
                        String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ? AND especie = ?";
                        PreparedStatement stmt = con.prepareStatement(sql);
                        stmt.setInt(1,idUsuarioAtual);
                        stmt.setString(2, especieSelecionada);
                        ResultSet rs = stmt.executeQuery();

                        // Limpar as listas antes de adicionar novos dados
                        listaIdPet.clear();
                        listaNomePet.clear();
                        listaFotoPet.clear();

                        // Preencher as listas com dados do banco
                        while (rs.next()) {
                            String id1 = rs.getString("id_pet");
                            String nome = rs.getString("nome");
                            byte[] fotoBytes = rs.getBytes("foto");

                            // Converter a foto para Bitmap
                            Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                            // Chama o método para arredondar a imagem
                            Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                            // Adicionar os dados nas listas
                            listaIdPet.add(id1);
                            listaNomePet.add(nome);
                            listaFotoPet.add(roundedBitmap);
                        }

                        rs.close();
                        stmt.close();
                        con.close();

                        // Atualize o RecyclerView com os dados filtrados
                        updateRecyclerView();

                        funMostrarLayoutSuperior();

                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btDeletarPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Confirme para excluir o PET " +nomePetClicado+".")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarPet();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        btVoltarListaPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funPetIsNull();
                funListaPets();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // Criar a lista de portePet
        List<String> portePetList = Arrays.asList("Pequeno", "Médio", "Grande");
        // Criar o ArrayAdapter e associar ao Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), R.layout.spinner_item, portePetList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        portePet.setAdapter(adapter);

        // Criar a lista de sexoPet
        List<String> sexoPetList = Arrays.asList("Macho", "Fêmea");
        // Criar o ArrayAdapter e associar ao Spinner
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(getActivity(), R.layout.spinner_item, sexoPetList);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sexoPet.setAdapter(adapter1);

        primeiraSelecaoSpinner = true;

        funFiltrarEspecie();
        funListaPets();
        funPetIsNull();
    }

    public static class DateValidator {

        /* Verifica se a string está no formato dd/MM/yyyy e é uma data possível. */
        public static boolean isValidDate(String dateStr) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);           // NÃO aceita 32/13/2025 …

            try {
                Date date = sdf.parse(dateStr);

                // Opcional: limite de ano (ajuste se quiser)
                int year = Integer.parseInt(dateStr.substring(6));
                return year >= 1900 && year <= 2100;
            } catch (ParseException | NumberFormatException e) {
                return false;
            }
        }
    }

    public class DateInputFilter implements InputFilter {

        @Override
        public CharSequence filter(CharSequence source, int start, int end,
                                   Spanned dest, int dstart, int dend) {

            // Monta como ficará o texto se aceitarmos a digitação
            StringBuilder builder = new StringBuilder(dest);
            builder.replace(dstart, dend, source.subSequence(start, end).toString());
            String result = builder.toString();

            // Remove barras para validar só os dígitos
            String digits = result.replaceAll("[^\\d]", "");

            // Limite absoluto: 8 dígitos (ddMMyyyy)
            if (digits.length() > 8) return "";

            // Validação incremental: DIA
            if (digits.length() >= 1) {
                int diaDezena = Character.getNumericValue(digits.charAt(0));
                if (diaDezena > 3) return "";
            }
            if (digits.length() >= 2) {
                int dia = Integer.parseInt(digits.substring(0, 2));
                if (dia < 1 || dia > 31) return "";
            }

            // Validação incremental: MÊS
            if (digits.length() >= 4) {
                int mes = Integer.parseInt(digits.substring(2, 4));
                if (mes < 1 || mes > 12) return "";
            }

            // Validação incremental: ANO (opcional)
            if (digits.length() == 8) {
                int ano = Integer.parseInt(digits.substring(4, 8));
                if (ano < 1900 || ano > 2100) return "";
            }

            // Tudo OK: aceita a digitação
            return null;
        }
    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    public void funCadastrarPet() {
        String nome = nomePet.getText().toString().trim();
        String especie = especiePet.getText().toString().trim();
        String raca = racaPet.getText().toString().trim();
        String cor = corPet.getText().toString().trim();
        String peso = pesoPet.getText().toString().trim();
        String porte = portePet.getSelectedItem().toString();
        String sexo = sexoPet.getSelectedItem().toString();
        String descricao = descricaoPet.getText().toString().trim();
        String dataStr = dtNascimentoPet.getText().toString().trim();

        // Verificando se a ImageView está vazia
        Drawable drawable = imgPet.getDrawable();
        byte[] byteArray = null;

        // Validações de obrigatoriedade
        if (nome.isEmpty()){ nomePet.setError("Campo obrigatório"); return; }
        if (especie.isEmpty()){ especiePet.setError("Campo obrigatório"); return; }
        if (dataStr.isEmpty()){ dtNascimentoPet.setError("Campo obrigatório"); return; }

        // Verifica se o usuário selecionou uma imagem, senão usa padrão
        if (drawable != null && selectedBitmap != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            selectedBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            byteArray = byteArrayOutputStream.toByteArray();
        } else {
            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.patas);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            defaultBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            byteArray = byteArrayOutputStream.toByteArray();
        }

        // Validação de formato/consistência da data
        if (!petFragment.DateValidator.isValidDate(dataStr)) {
            dtNascimentoPet.setError("Data inválida");
            return;
        }

        // Conversão segura String para java.sql.Date
        java.sql.Date dataSql;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            dataSql = new java.sql.Date(sdf.parse(dataStr).getTime());
        } catch (ParseException e) {
            // Só deve ocorrer em caso de erro muito improvável
            dtNascimentoPet.setError("Data inválida");
            Toast.makeText(getActivity(), "Erro ao converter a data", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "INSERT INTO pet (nome, foto, descricao, especie, raca, cor, sexo, porte, peso, dt_nascimento, fk_id_tutor) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, nome);
            stmt.setBytes(2, byteArray);
            stmt.setString(3, descricao);
            stmt.setString(4, especie);
            stmt.setString(5, raca);
            stmt.setString(6, cor);
            stmt.setString(7, sexo);
            stmt.setString(8, porte);

            if(!peso.isEmpty()) {
                stmt.setDouble(9, Double.parseDouble(peso));
            } else {
                stmt.setDouble(9, 0);
            }

            stmt.setDate(10, dataSql);
            stmt.setInt(11,idUsuarioAtual);  // id do usuário (supondo que você tenha isso)
            stmt.executeUpdate();

            stmt.close();
            con.close();

            // Atualização UI
            funMostrarLayoutSuperior();
            funListaPets();
            funDesativarCampos();
            funFiltrarEspecie();
            btAlterarPet.setVisibility(GONE);

            imageChanged = false;
            primeiraSelecaoSpinner = true;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaPets() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdPet.clear();
            listaNomePet.clear();
            listaFotoPet.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_pet");
                String nome = rs.getString("nome");
                byte[] fotoBytes = rs.getBytes("foto");

                Bitmap roundedBitmap = null;

                if (fotoBytes != null) {
                    // Converte a foto em Bitmap
                    Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                    // Arredonda a imagem
                    roundedBitmap = getRoundedBitmap(fotoBitmap);
                }

                // Adicionar os dados nas listas
                listaIdPet.add(id);
                listaNomePet.add(nome);
                listaFotoPet.add(roundedBitmap);
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            // Atualize o RecyclerView com os dados
            updateRecyclerView();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModels.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdPet.size(); i++) {
            MainModel model = new MainModel(listaFotoPet.get(i), listaIdPet.get(i), listaNomePet.get(i));
            mainModels.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapter.notifyDataSetChanged();
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }

    public void funFiltrarEspecie() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT DISTINCT especie FROM pet WHERE fk_id_tutor = ? ORDER BY especie ASC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Criar uma lista de String para o Spinner
            List<String> filtrarEspecieList = new ArrayList<>();

            while (rs.next()) {
                filtrarEspecieList.add(rs.getString("especie"));
            }

            // Criar o ArrayAdapter e associar ao Spinner
            ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getActivity(), R.layout.spinner_item, filtrarEspecieList);
            adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            filtrarEspecie.setAdapter(adapter2);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funAtualizarPet() {

        String nome = nomePet.getText().toString().trim();
        String especie = especiePet.getText().toString().trim();
        String raca = racaPet.getText().toString().trim();
        String cor = corPet.getText().toString().trim();
        String peso = pesoPet.getText().toString().trim();
        String porte = portePet.getSelectedItem().toString();
        String sexo = sexoPet.getSelectedItem().toString();
        String descricao = descricaoPet.getText().toString().trim();
        String dataStr = dtNascimentoPet.getText().toString().trim();

        // Validações de obrigatoriedade
        if (nome.isEmpty()){ nomePet.setError("Campo obrigatório");   return; }
        if (especie.isEmpty()){ especiePet.setError("Campo obrigatório");   return; }

        // Validação de formato/consistência da data
        if (!petFragment.DateValidator.isValidDate(dataStr)) {
            dtNascimentoPet.setError("Data inválida");
            return;
        }

        // Conversão segura String para java.sql.Date
        java.sql.Date dataSql;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            dataSql = new java.sql.Date(sdf.parse(dataStr).getTime());
        } catch (ParseException e) {
            // Só deve ocorrer em caso de erro muito improvável
            dtNascimentoPet.setError("Data inválida");
            Toast.makeText(getActivity(), "Erro ao converter a data", Toast.LENGTH_SHORT).show();
            return;
        }

        // Se a imagem foi alterada
        byte[] imgBytes = null;
        if (imageChanged) {
            // Se uma nova imagem foi selecionada, converte para bytes
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            selectedBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            imgBytes = byteArrayOutputStream.toByteArray();
        } else {
            // Caso a imagem não tenha sido alterada, recupere a imagem existente do banco de dados
            imgBytes = getImgBytesFromDatabase(String.valueOf(idPetClicado));  // Supondo que você tenha um método para recuperar a imagem do banco
        }

        // Atualiza o banco de dados
        try {
            Connection con = ConexaoMysql.conectar();
            String sql;
            PreparedStatement stmt;

            if (imageChanged) {
                // Atualiza com a nova foto, caso tenha sido alterada
                sql = "UPDATE pet SET nome=?, foto=?, descricao=?, especie=?, raca=?, cor=?, sexo=?, porte=?, peso=?, dt_nascimento=? WHERE id_pet = ?";
                stmt = con.prepareStatement(sql);

                stmt.setString(1, nome);
                stmt.setBytes(2, imgBytes); // Define a nova foto
                stmt.setString(3, descricao);
                stmt.setString(4, especie);
                stmt.setString(5, raca);
                stmt.setString(6, cor);
                stmt.setString(7, sexo);
                stmt.setString(8, porte);

                if(!peso.isEmpty()) {
                    stmt.setDouble(9, Double.parseDouble(peso));
                } else {
                    stmt.setDouble(9, 0);
                }

                stmt.setDate(10, dataSql);
                stmt.setInt(11, idPetClicado);
            } else {
                // Se a imagem não foi alterada, atualiza sem tocar na foto
                sql = "UPDATE pet SET nome=?, descricao=?, especie=?, raca=?, cor=?, sexo=?, porte=?, peso=?, dt_nascimento=? WHERE id_pet = ?";
                stmt = con.prepareStatement(sql);

                stmt.setString(1, nome);
                stmt.setString(2, descricao);
                stmt.setString(3, especie);
                stmt.setString(4, raca);
                stmt.setString(5, cor);
                stmt.setString(6, sexo);
                stmt.setString(7, porte);

                if(!peso.isEmpty()) {
                    stmt.setDouble(8, Double.parseDouble(peso));
                } else {
                    stmt.setDouble(8,0);
                }

                stmt.setDate(9, dataSql);
                stmt.setInt(10, idPetClicado);
            }

            stmt.executeUpdate();

            funListaPets();
            funFiltrarEspecie();
            funDesativarCampos();

            imageChanged = false;
            primeiraSelecaoSpinner = true;

            stmt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(String idPet) {
        byte[] imgBytesAtual = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM pet WHERE id_pet = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, idPet);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imgBytesAtual;
    }

    public void funDeletarPet() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM pet WHERE id_pet = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idPetClicado);
            stmt.execute();

            stmt.close();
            con.close();

            funFiltrarEspecie();
            funListaPets();
            funMostrarLayoutSuperior();
            funLimparCamposAddPet();

            imgPet.setImageDrawable(null);
            primeiraSelecaoSpinner = true;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        funPetIsNull();
    }

    public void funPetIsNull() {

        verificarPetIsNull = false;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM pet WHERE fk_id_tutor = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                verificarPetIsNull = true;
            }

            if (verificarPetIsNull) {
                btSelecionarFoto.setVisibility(GONE);
                imgPet.setVisibility(GONE);
                nomePet.setVisibility(GONE);
                especiePet.setVisibility(GONE);
                racaPet.setVisibility(GONE);
                pesoPet.setVisibility(GONE);
                sexoPet.setVisibility(GONE);
                portePet.setVisibility(GONE);
                corPet.setVisibility(GONE);
                descricaoPet.setVisibility(GONE);
                dtNascimentoPet.setVisibility(GONE);
                countTextDescPet.setVisibility(GONE);
                btSalvarNovoPet.setVisibility(GONE);
                btAddPrimeiroPet.setVisibility(GONE);
                btAlterarPet.setVisibility(GONE);
                btDeletarPet.setVisibility(GONE);
                tvNomePet.setVisibility(GONE);
                tvCorPet.setVisibility(GONE);
                tvEspeciePet.setVisibility(GONE);
                tvRacaPet.setVisibility(GONE);
                tvSexoPet.setVisibility(GONE);
                tvPortePet.setVisibility(GONE);
                tvPesoPet.setVisibility(GONE);
                tvBioPet.setVisibility(GONE);
                btVoltarListaPet.setVisibility(GONE);
                btSalvarNovoPet.setVisibility(GONE);
                btDeletarPet.setVisibility(GONE);
                btAlterarPet.setVisibility(GONE);
                btAtualizarPet.setVisibility(GONE);
                filtrarEspecie.setVisibility(VISIBLE);
                linearLayout4.setVisibility(VISIBLE);
                listaPets.setVisibility(VISIBLE);
                textFiltrarEspecie.setVisibility(VISIBLE);
                btAddNovoPet.setVisibility(VISIBLE);
            } else {
                funEsconderLayout();
                btAddPrimeiroPet.setVisibility(VISIBLE);
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funAtivarCampos() {
        nomePet.setEnabled(true);
        corPet.setEnabled(true);
        pesoPet.setEnabled(true);
        especiePet.setEnabled(true);
        racaPet.setEnabled(true);
        portePet.setEnabled(true);
        sexoPet.setEnabled(true);
        descricaoPet.setEnabled(true);
        dtNascimentoPet.setEnabled(true);

        // Outro metodo para ativar campos
        /*
        nomePet.setFocusable(true);
        nomePet.setFocusableInTouchMode(true); // Garante que o teclado não abre
        nomePet.setCursorVisible(true);
        nomePet.setLongClickable(true);

        descricaoPet.setFocusable(true);
        descricaoPet.setFocusableInTouchMode(true);
        descricaoPet.setCursorVisible(true);
        descricaoPet.setLongClickable(true);
        descricaoPet.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        */

        btSelecionarFoto.setEnabled(true);
        btAlterarPet.setVisibility(GONE);
        btSalvarNovoPet.setVisibility(GONE);
        btAtualizarPet.setVisibility(VISIBLE);
    }

    public void funDesativarCampos() {
        nomePet.setEnabled(false);
        corPet.setEnabled(false);
        pesoPet.setEnabled(false);
        especiePet.setEnabled(false);
        racaPet.setEnabled(false);
        portePet.setEnabled(false);
        sexoPet.setEnabled(false);
        descricaoPet.setEnabled(false);
        dtNascimentoPet.setEnabled(false);

        // Outro metodo para desativar campos
        /*
        nomePet.setFocusable(false);
        nomePet.setFocusableInTouchMode(false); // Garante que o teclado não abre
        nomePet.setCursorVisible(false);
        nomePet.setLongClickable(false);
        */

        btSelecionarFoto.setEnabled(false);
        btAtualizarPet.setVisibility(GONE);
        btSalvarNovoPet.setVisibility(GONE);
        btAlterarPet.setVisibility(VISIBLE);

        nomePet.setError(null);
        especiePet.setError(null);
        dtNascimentoPet.setError(null);
    }

    public void funLimparCamposAddPet() {
        funAtivarCampos();
        nomePet.setText(null);
        corPet.setText(null);
        pesoPet.setText(null);
        especiePet.setText(null);
        racaPet.setText(null);
        portePet.setSelection(0);;
        sexoPet.setSelection(0);
        descricaoPet.setText(null);
        dtNascimentoPet.setText(null);

        nomePet.setError(null);
        especiePet.setError(null);
        dtNascimentoPet.setError(null);

        portePet.setEnabled(true);
        portePet.setClickable(true);

        sexoPet.setEnabled(true);
        sexoPet.setClickable(true);

        btSelecionarFoto.setEnabled(true);
        btSelecionarFoto.setAlpha(1);
        btAtualizarPet.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        btDeletarPet.setVisibility(GONE);
        btSalvarNovoPet.setVisibility(VISIBLE);
    }

    public void funMostrarLayout() {
        btSelecionarFoto.setVisibility(VISIBLE);
        imgPet.setVisibility(VISIBLE);
        nomePet.setVisibility(VISIBLE);
        especiePet.setVisibility(VISIBLE);
        racaPet.setVisibility(VISIBLE);
        pesoPet.setVisibility(VISIBLE);
        sexoPet.setVisibility(VISIBLE);
        portePet.setVisibility(VISIBLE);
        corPet.setVisibility(VISIBLE);
        descricaoPet.setVisibility(VISIBLE);
        dtNascimentoPet.setVisibility(VISIBLE);
        countTextDescPet.setVisibility(VISIBLE);
        btSalvarNovoPet.setVisibility(VISIBLE);
        filtrarEspecie.setVisibility(VISIBLE);
        listaPets.setVisibility(VISIBLE);
        textFiltrarEspecie.setVisibility(VISIBLE);
        btAddNovoPet.setVisibility(VISIBLE);
        tvNomePet.setVisibility(VISIBLE);
        tvCorPet.setVisibility(VISIBLE);
        tvEspeciePet.setVisibility(VISIBLE);
        tvRacaPet.setVisibility(VISIBLE);
        tvSexoPet.setVisibility(VISIBLE);
        tvPortePet.setVisibility(VISIBLE);
        tvPesoPet.setVisibility(VISIBLE);
        tvBioPet.setVisibility(VISIBLE);
        btAddPrimeiroPet.setVisibility(GONE);
    }

    public void funMostrarLayoutAddPet() {
        btSelecionarFoto.setVisibility(VISIBLE);
        imgPet.setVisibility(VISIBLE);
        nomePet.setVisibility(VISIBLE);
        especiePet.setVisibility(VISIBLE);
        racaPet.setVisibility(VISIBLE);
        pesoPet.setVisibility(VISIBLE);
        sexoPet.setVisibility(VISIBLE);
        portePet.setVisibility(VISIBLE);
        corPet.setVisibility(VISIBLE);
        descricaoPet.setVisibility(VISIBLE);
        dtNascimentoPet.setVisibility(VISIBLE);
        countTextDescPet.setVisibility(VISIBLE);
        btSalvarNovoPet.setVisibility(VISIBLE);
        tvNomePet.setVisibility(VISIBLE);
        tvCorPet.setVisibility(VISIBLE);
        tvEspeciePet.setVisibility(VISIBLE);
        tvRacaPet.setVisibility(VISIBLE);
        tvSexoPet.setVisibility(VISIBLE);
        tvPortePet.setVisibility(VISIBLE);
        tvPesoPet.setVisibility(VISIBLE);
        tvBioPet.setVisibility(VISIBLE);
        btVoltarListaPet.setVisibility(VISIBLE);
        btAddPrimeiroPet.setVisibility(GONE);
        linearLayout4.setVisibility(GONE);
        filtrarEspecie.setVisibility(GONE);
        listaPets.setVisibility(GONE);
        textFiltrarEspecie.setVisibility(GONE);
        btAddNovoPet.setVisibility(GONE);
    }

    public void funEsconderLayout() {
        btSelecionarFoto.setVisibility(GONE);
        imgPet.setVisibility(GONE);
        nomePet.setVisibility(GONE);
        especiePet.setVisibility(GONE);
        racaPet.setVisibility(GONE);
        pesoPet.setVisibility(GONE);
        sexoPet.setVisibility(GONE);
        portePet.setVisibility(GONE);
        corPet.setVisibility(GONE);
        descricaoPet.setVisibility(GONE);
        dtNascimentoPet.setVisibility(GONE);
        countTextDescPet.setVisibility(GONE);
        btSalvarNovoPet.setVisibility(GONE);
        btAtualizarPet.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        filtrarEspecie.setVisibility(GONE);
        listaPets.setVisibility(GONE);
        textFiltrarEspecie.setVisibility(GONE);
        btAddNovoPet.setVisibility(GONE);
        linearLayout4.setVisibility(GONE);
        btDeletarPet.setVisibility(GONE);
        tvNomePet.setVisibility(GONE);
        tvCorPet.setVisibility(GONE);
        tvEspeciePet.setVisibility(GONE);
        tvRacaPet.setVisibility(GONE);
        tvSexoPet.setVisibility(GONE);
        tvPortePet.setVisibility(GONE);
        tvPesoPet.setVisibility(GONE);
        tvBioPet.setVisibility(GONE);
        btVoltarListaPet.setVisibility(GONE);
    }

    public void funMostrarPrimeiroLayout() {
        btSelecionarFoto.setVisibility(VISIBLE);
        imgPet.setVisibility(VISIBLE);
        nomePet.setVisibility(VISIBLE);
        especiePet.setVisibility(VISIBLE);
        racaPet.setVisibility(VISIBLE);
        pesoPet.setVisibility(VISIBLE);
        sexoPet.setVisibility(VISIBLE);
        portePet.setVisibility(VISIBLE);
        corPet.setVisibility(VISIBLE);
        descricaoPet.setVisibility(VISIBLE);
        dtNascimentoPet.setVisibility(VISIBLE);
        countTextDescPet.setVisibility(VISIBLE);
        btSalvarNovoPet.setVisibility(VISIBLE);
        tvNomePet.setVisibility(VISIBLE);
        tvCorPet.setVisibility(VISIBLE);
        tvEspeciePet.setVisibility(VISIBLE);
        tvRacaPet.setVisibility(VISIBLE);
        tvSexoPet.setVisibility(VISIBLE);
        tvPortePet.setVisibility(VISIBLE);
        tvPesoPet.setVisibility(VISIBLE);
        tvBioPet.setVisibility(VISIBLE);
        btAddPrimeiroPet.setVisibility(GONE);
        btAddNovoPet.setVisibility(GONE);
        btDeletarPet.setVisibility(GONE);
        textFiltrarEspecie.setVisibility(GONE);
        filtrarEspecie.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        btVoltarListaPet.setVisibility(GONE);
    }

    public void funMostrarLayoutSuperior() {
        btSelecionarFoto.setVisibility(GONE);
        imgPet.setVisibility(GONE);
        nomePet.setVisibility(GONE);
        especiePet.setVisibility(GONE);
        racaPet.setVisibility(GONE);
        pesoPet.setVisibility(GONE);
        sexoPet.setVisibility(GONE);
        portePet.setVisibility(GONE);
        corPet.setVisibility(GONE);
        descricaoPet.setVisibility(GONE);
        dtNascimentoPet.setVisibility(GONE);
        countTextDescPet.setVisibility(GONE);
        btSalvarNovoPet.setVisibility(GONE);
        btAddPrimeiroPet.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        btDeletarPet.setVisibility(GONE);
        tvNomePet.setVisibility(GONE);
        tvCorPet.setVisibility(GONE);
        tvEspeciePet.setVisibility(GONE);
        tvRacaPet.setVisibility(GONE);
        tvSexoPet.setVisibility(GONE);
        tvPortePet.setVisibility(GONE);
        tvPesoPet.setVisibility(GONE);
        tvBioPet.setVisibility(GONE);
        btVoltarListaPet.setVisibility(GONE);
        linearLayout4.setVisibility(VISIBLE);
        filtrarEspecie.setVisibility(VISIBLE);
        listaPets.setVisibility(VISIBLE);
        textFiltrarEspecie.setVisibility(VISIBLE);
        btAddNovoPet.setVisibility(VISIBLE);
    }

    public void funMostrarLayoutPet() {
        btVoltarListaPet.setVisibility(VISIBLE);
        btSelecionarFoto.setVisibility(VISIBLE);
        imgPet.setVisibility(VISIBLE);
        nomePet.setVisibility(VISIBLE);
        especiePet.setVisibility(VISIBLE);
        racaPet.setVisibility(VISIBLE);
        pesoPet.setVisibility(VISIBLE);
        sexoPet.setVisibility(VISIBLE);
        portePet.setVisibility(VISIBLE);
        corPet.setVisibility(VISIBLE);
        descricaoPet.setVisibility(VISIBLE);
        dtNascimentoPet.setVisibility(VISIBLE);
        countTextDescPet.setVisibility(VISIBLE);
        btSalvarNovoPet.setVisibility(VISIBLE);
        btDeletarPet.setVisibility(VISIBLE);
        tvNomePet.setVisibility(VISIBLE);
        tvCorPet.setVisibility(VISIBLE);
        tvEspeciePet.setVisibility(VISIBLE);
        tvRacaPet.setVisibility(VISIBLE);
        tvSexoPet.setVisibility(VISIBLE);
        tvPortePet.setVisibility(VISIBLE);
        tvPesoPet.setVisibility(VISIBLE);
        tvBioPet.setVisibility(VISIBLE);
        listaPets.setVisibility(GONE);
        btAddPrimeiroPet.setVisibility(GONE);
        btAddNovoPet.setVisibility(GONE);
        btDeletarPet.setVisibility(GONE);
        textFiltrarEspecie.setVisibility(GONE);
        filtrarEspecie.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        linearLayout4.setVisibility(GONE);
    }

}