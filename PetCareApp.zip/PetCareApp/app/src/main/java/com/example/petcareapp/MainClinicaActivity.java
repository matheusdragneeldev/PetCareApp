package com.example.petcareapp;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.petcareapp.databinding.ActivityMainClinicaBinding;
import com.google.firebase.auth.FirebaseAuth;

public class MainClinicaActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainClinicaBinding binding;

    // Declara o lançador para o pedido de permissão
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // Permissão concedida. Você pode querer habilitar alguma funcionalidade
                    // relacionada a notificações aqui.
                } else {
                    // Permissão negada. Informe ao usuário que ele não receberá notificações.
                    // Você pode mostrar um Toast ou um Snackbar.
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainClinicaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMainClinica.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        NotificationHelper.createNotificationChannel(this); // Chame aqui
        askNotificationPermission();

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
               R.id.nav_perfil_clinica, R.id.nav_doenca, R.id.nav_guia,R.id.nav_campanha, R.id.nav_mensagem, R.id.nav_feedback, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main_clinica);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_clinica, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) { //Ação do Menu
        // Se o item do menu for selecionado, navegue para o fragmento de configurações

        if (item.getItemId() == R.id.action_sair) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(MainClinicaActivity.this, LoginActivity.class);
            // Finaliza telas anteriores, impedindo de voltar após o logout
            //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }

        if (item.getItemId() == R.id.action_seguranca) {
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main_clinica); //Nav MainActivity
            // Navegue para o fragmento desejado
            navController.navigate(R.id.nav_seguranca); // Nav da Tela
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main_clinica);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private void askNotificationPermission() {
        // Esta verificação só é necessária para Android 13 (TIRAMISU) ou superior
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED) {
                // A permissão já foi concedida.
            } else {
                // A permissão ainda não foi concedida, então solicite-a.
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }

}