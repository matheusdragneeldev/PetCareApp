package com.example.petcareapp.ui.mensagem;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;

import com.example.petcareapp.ui.mensagemPerfil.mensagemPerfilFragment;
import com.example.petcareapp.util.FragmentArgs;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.MainAdapter;
import com.example.petcareapp.ui.pet.MainModel;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link mensagemFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class mensagemFragment extends Fragment {

    String emailUsuarioAtual, tipoUserAtual, nomeContatoClicado;
    Integer idUsuarioAtual, idContatoClicado;

    // Executor para operações em segundo plano
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    RecyclerView listaContatos, listaMsg;

    Button btVerPerfil;
    ImageButton btEnviarMensagem;
    ImageButton btVoltarContatos;
    EditText caixaMensagem, pesquisarContato;
    TextView tvContatoNull, tvNomeConversando;
    ProgressBar progressBar;
    ConstraintLayout mainContentLayout;

    ArrayList<MainModelContato> mainModels = new ArrayList<>();
    ArrayList<MainModelMsg> mainModelsMsg = new ArrayList<>();

    MainAdapterContato mainAdapterContato;
    MainAdapterMsg mainAdapterMsg;

    private final TextWatcher textWatcherBusca = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            funPesquisarContato(s.toString());
        }

        @Override
        public void afterTextChanged(Editable s) {}
    };

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public mensagemFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment mensagemFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static mensagemFragment newInstance(String param1, String param2) {
        mensagemFragment fragment = new mensagemFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_mensagem, container, false);

        // Iniciando componentes
        listaContatos = view.findViewById(R.id.listaContatos);
        listaMsg = view.findViewById(R.id.listaMsg);
        btEnviarMensagem = view.findViewById(R.id.btEnviarMensagem);
        caixaMensagem = view.findViewById(R.id.caixaMensagem);
        btVoltarContatos = view.findViewById(R.id.btVoltarContatos);
        pesquisarContato = view.findViewById(R.id.pesquisarContato);
        tvContatoNull = view.findViewById(R.id.tvContatoNull);
        btVerPerfil = view.findViewById(R.id.btVerPerfil);
        tvNomeConversando = view.findViewById(R.id.tvNomeConversando);
        mainContentLayout = view.findViewById(R.id.mainContentLayout);
        progressBar = view.findViewById(R.id.progressBar);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaContatos.setLayoutManager(layoutManager);
        listaContatos.setItemAnimator(new DefaultItemAnimator());

        // Inicia MainAdapter
        mainAdapterContato = new MainAdapterContato(getActivity(), mainModels, new MainAdapterContato.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelContato model) {
                try {
                    // Atualiza o estado com o novo contato clicado
                    idContatoClicado = Integer.valueOf(model.getListaIdContato());
                    nomeContatoClicado = model.getListaNomeContato();

                    // --- CORREÇÃO ADICIONADA AQUI ---
                    // 1. Limpa a lista de mensagens do chat anterior IMEDIATAMENTE.
                    if (mainModelsMsg != null) {
                        mainModelsMsg.clear();
                    }
                    // 2. Notifica o adapter que a lista está vazia AGORA.
                    //    Isso remove os itens antigos da tela instantaneamente.
                    if (mainAdapterMsg != null) {
                        mainAdapterMsg.notifyDataSetChanged();
                    }
                    // --- FIM DA CORREÇÃO ---

                    // 3. Mostra a tela de chat (que agora estará vazia)
                    funMostrarMensagens();

                    // 4. Inicia a busca pelas novas mensagens em background
                    funAtualizarMensagens();

                } catch (Exception e) {
                    e.printStackTrace();
                    throw new RuntimeException("Erro ao processar clique no contato", e);
                }
            }
        });

        // Set MainAdapter para listaContato
        listaContatos.setAdapter(mainAdapterContato);

        btEnviarMensagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensagem = caixaMensagem.getText().toString().trim();
                // Verifica se a mensagem não está vazia antes de tentar enviar
                if (!mensagem.isEmpty()) {
                    // Captura a mensagem e o timestamp na thread da UI antes de ir para o background.
                    // Isso garante que os valores sejam consistentes mesmo que o usuário digite algo novo
                    // enquanto a operação de banco de dados está em andamento.
                    final String finalMensagem = mensagem;
                    final java.sql.Timestamp timestampAtual = new java.sql.Timestamp(System.currentTimeMillis());

                    // Executa a operação de inserção no banco de dados em uma thread separada.
                    // Isso evita que a UI seja bloqueada.
                    executor.execute(() -> {
                        Connection con = null;
                        PreparedStatement stmt = null;
                        try {
                            con = ConexaoMysql.conectar(); // Tenta conectar ao banco de dados
                            String sql = "INSERT INTO mensagens(id_remetente,id_destinatario,mensagem,dt_hr_mensagem)VALUES(?,?,?,?);";
                            stmt = con.prepareStatement(sql);
                            // Define os parâmetros para a query SQL
                            // Assumindo que 'idUsuarioAtual' e 'idContatoClicado' são membros da classe
                            // e já foram populados corretamente.
                            stmt.setInt(1, idUsuarioAtual);
                            stmt.setInt(2, idContatoClicado);
                            stmt.setString(3, finalMensagem);
                            stmt.setTimestamp(4, timestampAtual);
                            stmt.execute(); // Executa a inserção no banco de dados

                            // Posta as atualizações da UI para a thread principal após o sucesso da inserção.
                            // Todas as operações que modificam a UI devem ser feitas na thread principal.
                            handler.post(() -> {
                                caixaMensagem.setText(null); // Limpa a caixa de mensagem na UI
                                funAtualizarMensagens(); // Atualiza a lista de mensagens na UI
                            });

                        } catch (Exception e) {
                            e.printStackTrace(); // Imprime o stack trace do erro para depuração
                            // Exibe um Toast de erro na UI thread se algo der errado na operação do banco de dados.
                            handler.post(() -> Toast.makeText(getContext(), "Erro ao enviar mensagem: " + e.getMessage(), Toast.LENGTH_LONG).show());
                        } finally {
                            // Garante que os recursos do banco de dados (Statement e Connection) sejam fechados.
                            // Isso é crucial para evitar vazamentos de recursos e problemas de conexão.
                            try {
                                if (stmt != null) stmt.close();
                                if (con != null) con.close();
                            } catch (Exception e) {
                                e.printStackTrace(); // Imprime erros ao fechar recursos
                            }
                        }
                    });
                } else {
                    // Opcional: feedback para o usuário se a mensagem estiver vazia.
                    // Toast.makeText(getContext(), "A mensagem não pode estar vazia.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btVoltarContatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funMostrarContatos();
            }
        });

        btVerPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                irParaPerfil(view, idContatoClicado.toString());
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Mostra o ProgressBar
        if (progressBar != null) progressBar.setVisibility(VISIBLE);
        if (mainContentLayout != null) mainContentLayout.setVisibility(GONE);

        executor.execute(() -> {
            // Busca os dados do usuário em background (código existente)
            String emailUsuarioAtual = (FirebaseAuth.getInstance().getCurrentUser() != null)
                    ? FirebaseAuth.getInstance().getCurrentUser().getEmail()
                    : null;

            if (emailUsuarioAtual == null) {
                handler.post(() -> Toast.makeText(getContext(), "Erro: Usuário não autenticado.", Toast.LENGTH_SHORT).show());
                return;
            }

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login, tipo_user FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                    tipoUserAtual = rs.getString("tipo_user");

                    // --- LÓGICA DE DECISÃO CORRIGIDA ---
                    handler.post(() -> {
                        // Esconde o ProgressBar e mostra o conteúdo principal
                        progressBar.setVisibility(GONE);
                        mainContentLayout.setVisibility(VISIBLE);

                        // VERIFICA O ESTADO: Já estávamos em uma conversa?
                        if (idContatoClicado != null) {
                            // Se SIM, restaura a tela de chat em vez da lista de contatos.
                            funMostrarMensagens();
                            funAtualizarMensagens(); // Recarrega as mensagens da conversa ativa
                        } else {
                            // Se NÃO, é o fluxo normal de início. Carrega a lista de contatos.
                            funListaConato();
                            funMostrarContatos();
                        }

                        // A lógica do TextWatcher continua a mesma
                        if (pesquisarContato != null && textWatcherBusca != null) {
                            pesquisarContato.removeTextChangedListener(textWatcherBusca);
                            pesquisarContato.addTextChangedListener(textWatcherBusca);
                        }
                    });
                } else {
                    handler.post(() -> Toast.makeText(getContext(), "Erro: Tipo de usuário não encontrado.", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(getContext(), "Erro ao buscar dados do usuário.", Toast.LENGTH_LONG).show());
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Garante que o ExecutorService seja desligado quando o Fragment for destruído.
        // Isso libera os recursos da thread e evita vazamentos de memória.
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow(); // Tenta parar todas as tarefas em execução e as que estão na fila.
        }
    }

    public void funListaConato() {
        executor.execute(() -> {
            // Listas temporárias para guardar os dados brutos do banco
            final ArrayList<String> tempListaIdContato = new ArrayList<>();
            final ArrayList<byte[]> tempListaFotoContatoBytes = new ArrayList<>();
            final ArrayList<String> tempListaNomeContato = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();

                if ("Tutor".equals(tipoUserAtual)) {
                    String sql = "SELECT id_clinica, foto, nome FROM clinica";
                    stmt = con.prepareStatement(sql);
                    rs = stmt.executeQuery();

                    while (rs.next()) {
                        byte[] fotoBytes = rs.getBytes("foto");

                        if (fotoBytes != null && fotoBytes.length > 0) {
                            String id = rs.getString("id_clinica");
                            String nome = rs.getString("nome");

                            tempListaIdContato.add(id);
                            tempListaNomeContato.add(nome);
                            tempListaFotoContatoBytes.add(fotoBytes);
                        }
                    }
                } else if ("Clinica".equals(tipoUserAtual)) {
                    String sql = "SELECT DISTINCT remetente_id_tutor, remetente_foto_tutor, remetente_nome_tutor FROM view_mensagens WHERE destinatario_id_clinica = ?";
                    stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idUsuarioAtual);
                    rs = stmt.executeQuery();

                    while (rs.next()) {
                        byte[] fotoBytes = rs.getBytes("remetente_foto_tutor");

                        if (fotoBytes != null && fotoBytes.length > 0) {
                            String id = rs.getString("remetente_id_tutor");
                            String nome = rs.getString("remetente_nome_tutor");
                            tempListaIdContato.add(id);
                            tempListaNomeContato.add(nome);
                            tempListaFotoContatoBytes.add(fotoBytes); // Adicionamos os bytes (ou null)
                        }
                    }
                }

                // --- BLOCO HANDLER.POST CORRIGIDO E SIMPLIFICADO ---
                handler.post(() -> {
                    // 1. Criamos a lista de modelos para o DiffUtil
                    ArrayList<MainModelContato> novosModelos = new ArrayList<>();
                    for (int i = 0; i < tempListaIdContato.size(); i++) {
                        novosModelos.add(new MainModelContato(
                                tempListaIdContato.get(i),
                                tempListaFotoContatoBytes.get(i),
                                tempListaNomeContato.get(i)
                        ));
                    }

                    // 2. Chamamos o updateRecyclerView com a nova lista. Ele fará todo o trabalho.
                    updateRecyclerView(novosModelos);

                    // 3. Verificamos se a lista está vazia para mostrar a mensagem ao usuário.
                    funVerificarListaContato();
                });

            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(getContext(), "Erro ao carregar lista de contatos.", Toast.LENGTH_LONG).show());
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void updateRecyclerView(List<MainModelContato> novosModelos) {
        // 1. Cria o callback do DiffUtil, comparando a lista antiga com a nova
        ContatoDiffCallback diffCallback = new ContatoDiffCallback(this.mainModels, novosModelos);

        // 2. Calcula as diferenças de forma inteligente
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        // 3. ATUALIZA A LISTA PRINCIPAL, que é a fonte da verdade para o adapter
        this.mainModels.clear();
        this.mainModels.addAll(novosModelos);

        // 4. Envia as atualizações para o RecyclerView para que ele se atualize sem piscar!
        diffResult.dispatchUpdatesTo(mainAdapterContato);
    }

    private void irParaPerfil(View view, String idDoUsuario) {

        // Crie o pacote de dados
        Bundle args = new Bundle();
        args.putString("KEY_USER_ID", idDoUsuario);

        // Encontre o NavController e navegue para o destino, passando os dados
        NavController navController = Navigation.findNavController(getView());

        // Use o ID da "action" ou do destino definido no seu nav_graph.xml
        navController.navigate(R.id.nav_mensagem_perfil, args);
    }

    public void funMostrarContatos() {
        listaContatos.setVisibility(VISIBLE);
        pesquisarContato.setVisibility(VISIBLE);
        pesquisarContato.setText(null);
        tvNomeConversando.setVisibility(GONE);
        btVerPerfil.setVisibility(GONE);
        btEnviarMensagem.setVisibility(GONE);
        btVoltarContatos.setVisibility(GONE);
        caixaMensagem.setText(null);
        caixaMensagem.setVisibility(GONE);
        listaMsg.setVisibility(GONE);
        tvContatoNull.setVisibility(GONE);
    }

    public void funMostrarMensagens() {
        listaContatos.setVisibility(GONE);
        pesquisarContato.setVisibility(GONE);
        tvContatoNull.setVisibility(GONE);
        tvNomeConversando.setVisibility(VISIBLE);
        btVerPerfil.setVisibility(VISIBLE);
        btEnviarMensagem.setVisibility(VISIBLE);
        btVoltarContatos.setVisibility(VISIBLE);
        caixaMensagem.setVisibility(VISIBLE);
        listaMsg.setVisibility(VISIBLE);
    }

    public void funAtualizarMensagens() {
        if (tvNomeConversando != null && nomeContatoClicado != null) {
            tvNomeConversando.setText(nomeContatoClicado);
        }

        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            final ArrayList<MainModelMsg> tempMainModelsMsg = new ArrayList<>();

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT " +
                        "   COALESCE(m.remetente_id_tutor, m.remetente_id_clinica) AS id_remetente, " +
                        "   COALESCE(m.destinatario_id_tutor, m.destinatario_id_clinica) AS id_destinatario, " +
                        "   COALESCE(m.remetente_nome_tutor, m.remetente_nome_clinica) AS nome_remetente, " +
                        "   m.mensagem, " +
                        "   m.id_mensagem " +
                        "FROM view_mensagens m " +
                        "WHERE ( " +
                        "   (COALESCE(m.remetente_id_tutor, m.remetente_id_clinica) = ? AND " +
                        "    COALESCE(m.destinatario_id_tutor, m.destinatario_id_clinica) = ?) " +
                        "   OR " +
                        "   (COALESCE(m.remetente_id_tutor, m.remetente_id_clinica) = ? AND " +
                        "    COALESCE(m.destinatario_id_tutor, m.destinatario_id_clinica) = ?) " +
                        ") " +
                        "ORDER BY m.id_mensagem ASC";

                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                stmt.setInt(2, idContatoClicado);
                stmt.setInt(3, idContatoClicado);
                stmt.setInt(4, idUsuarioAtual);

                rs = stmt.executeQuery();

                // --- CÓDIGO PREENCHIDO AQUI ---
                while (rs.next()) {
                    Integer idMensagem = rs.getInt("id_mensagem");
                    Integer idRemetente = rs.getInt("id_remetente");
                    Integer idDestinatario = rs.getInt("id_destinatario");
                    String nomeRemetente = rs.getString("nome_remetente");
                    String mensagem = rs.getString("mensagem");

                    MainModelMsg modelMsg = new MainModelMsg(idMensagem, idRemetente, idDestinatario, nomeRemetente, mensagem);
                    tempMainModelsMsg.add(modelMsg);
                }
                // --- FIM DO CÓDIGO PREENCHIDO ---

                handler.post(() -> {
                    MensagemDiffCallback diffCallback = new MensagemDiffCallback(mainModelsMsg, tempMainModelsMsg);
                    DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

                    if (mainAdapterMsg == null || listaMsg.getAdapter() == null) {
                        mainAdapterMsg = new MainAdapterMsg(getActivity(), mainModelsMsg, idUsuarioAtual);
                        listaMsg.setLayoutManager(new LinearLayoutManager(getActivity()));
                        listaMsg.setAdapter(mainAdapterMsg);
                    }

                    mainModelsMsg.clear();
                    mainModelsMsg.addAll(tempMainModelsMsg);
                    diffResult.dispatchUpdatesTo(mainAdapterMsg);

                    if (!mainModelsMsg.isEmpty()) {
                        listaMsg.scrollToPosition(mainModelsMsg.size() - 1);
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(getContext(), "Erro ao carregar mensagens.", Toast.LENGTH_LONG).show());
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funVerificarListaContato() {
        // A verificação agora é feita na lista 'mainModels', que é a fonte de dados real do adapter.
        if (mainModels.isEmpty()) {
            tvContatoNull.setVisibility(VISIBLE);
        } else {
            tvContatoNull.setVisibility(GONE);
            pesquisarContato.setVisibility(VISIBLE);
        }
    }

    public void funPesquisarContato(String termo) {
        executor.execute(() -> {
            final ArrayList<String> tempListaIdContato = new ArrayList<>();
            final ArrayList<byte[]> tempListaFotoContatoBytes = new ArrayList<>();
            final ArrayList<String> tempListaNomeContato = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String filtro = "%" + termo.trim() + "%";
                String sql;

                if ("Tutor".equals(tipoUserAtual)) {
                    sql = "SELECT id_clinica, foto, nome FROM clinica WHERE LOWER(nome) LIKE LOWER(?)";
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1, filtro);
                } else { // "Clinica"
                    sql = "SELECT DISTINCT remetente_id_tutor, remetente_foto_tutor, remetente_nome_tutor FROM view_mensagens " +
                            "WHERE destinatario_id_clinica = ? AND LOWER(remetente_nome_tutor) LIKE LOWER(?)";
                    stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idUsuarioAtual);
                    stmt.setString(2, filtro);
                }

                rs = stmt.executeQuery();
                while (rs.next()) {
                    byte[] fotoBytes = rs.getBytes(2);
                    if (fotoBytes != null && fotoBytes.length > 0) { // Garante que contatos sem foto não apareçam na pesquisa
                        String id = rs.getString(1);
                        String nome = rs.getString(3);

                        tempListaIdContato.add(id);
                        tempListaFotoContatoBytes.add(fotoBytes);
                        tempListaNomeContato.add(nome);
                    }
                }

                handler.post(() -> {
                    ArrayList<MainModelContato> novosModelos = new ArrayList<>();
                    for (int i = 0; i < tempListaIdContato.size(); i++) {
                        novosModelos.add(new MainModelContato(
                                tempListaIdContato.get(i),
                                tempListaFotoContatoBytes.get(i),
                                tempListaNomeContato.get(i)
                        ));
                    }
                    updateRecyclerView(novosModelos); // Chama o método correto com a nova lista
                });

            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(getContext(), "Erro ao pesquisar contatos.", Toast.LENGTH_SHORT).show());
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

}