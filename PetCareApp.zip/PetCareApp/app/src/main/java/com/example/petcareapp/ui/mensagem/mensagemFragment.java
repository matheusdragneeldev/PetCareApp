package com.example.petcareapp.ui.mensagem;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.MainAdapter;
import com.example.petcareapp.ui.pet.MainModel;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link mensagemFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class mensagemFragment extends Fragment {

    String emailUsuarioAtual, tipoUserAtual;
    Integer idUsuarioAtual, idContatoClicado;

    RecyclerView listaContatos, listaMsg;

    Button btEnviarMensagem;
    ImageButton btVoltarContatos;
    EditText caixaMensagem, pesquisarContato;
    TextView tvContatoNull;

    ArrayList<String> listaIdContato = new ArrayList<>();
    ArrayList<Bitmap> listaFotoContato = new ArrayList<>();
    ArrayList<String> listaNomeContato = new ArrayList<>();
    ArrayList<MainModelContato> mainModels = new ArrayList<>();
    ArrayList<MainModelMsg> mainModelsMsg = new ArrayList<>();

    MainAdapterContato mainAdapterContato;
    MainAdapterMsg mainAdapterMsg;

    private final TextWatcher textWatcherBusca = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            funPesquisarContato(s.toString());
        }

        @Override
        public void afterTextChanged(Editable s) {}
    };

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public mensagemFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment mensagemFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static mensagemFragment newInstance(String param1, String param2) {
        mensagemFragment fragment = new mensagemFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_mensagem, container, false);

        // Iniciando componentes
        listaContatos = view.findViewById(R.id.listaContatos);
        listaMsg = view.findViewById(R.id.listaMsg);
        btEnviarMensagem = view.findViewById(R.id.btEnviarMensagem);
        caixaMensagem = view.findViewById(R.id.caixaMensagem);
        btVoltarContatos = view.findViewById(R.id.btVoltarContatos);
        pesquisarContato = view.findViewById(R.id.pesquisarContato);
        tvContatoNull = view.findViewById(R.id.tvContatoNull);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaContatos.setLayoutManager(layoutManager);
        listaContatos.setItemAnimator(new DefaultItemAnimator());

        // Inicia MainAdapter
        mainAdapterContato = new MainAdapterContato(getActivity(),mainModels);

        mainAdapterContato = new MainAdapterContato(getActivity(), mainModels, new MainAdapterContato.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelContato model) {
                try {
                    // Obtenha o nome do pet do modelo
                    idContatoClicado = Integer.valueOf(model.getListaIdContato());
                    funMostrarMensagens();
                    funAtualizarMensagens();
                } catch (Exception e) {
                    e.printStackTrace();
                    // Lança uma exceção personalizada ou trata o erro conforme necessário
                    throw new RuntimeException("Erro ao buscar detalhes do pet", e);
                }
            }
        });

        // Set MainAdapter para listaContato
        listaContatos.setAdapter(mainAdapterContato);

        btEnviarMensagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensagem = caixaMensagem.getText().toString().trim();
                if (!mensagem.isEmpty()) {
                    try {
                        Date dataAtual = new Date(System.currentTimeMillis());  // Pegando data/hora atual do sistema
                        java.sql.Timestamp timestampAtual = new java.sql.Timestamp(dataAtual.getTime()); // Convertendo para Timestamp, que é compatível com o tipo DATETIME no banco

                        Connection con = ConexaoMysql.conectar();
                        String sql = "INSERT INTO mensagens(id_remetente,id_destinatario,mensagem,dt_hr_mensagem)VALUES(?,?,?,?);";
                        PreparedStatement stmt = con.prepareStatement(sql);
                        stmt.setInt(1, idUsuarioAtual);
                        stmt.setInt(2, idContatoClicado);
                        stmt.setString(3, mensagem);
                        stmt.setTimestamp(4, timestampAtual);
                        stmt.execute();

                        stmt.close();
                        con.close();

                        caixaMensagem.setText(null);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                    funAtualizarMensagens();

                }
            }
        });

        btVoltarContatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funMostrarContatos();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, tipo_user FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                tipoUserAtual = rs.getString("tipo_user");
            }

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funListaConato();
        funMostrarContatos();

        pesquisarContato.removeTextChangedListener(textWatcherBusca);
        pesquisarContato.addTextChangedListener(textWatcherBusca);

    }

    public void funListaConato() {
        if (tipoUserAtual.equals("Tutor")) {
            try {
                Connection con = ConexaoMysql.conectar();
                String sql = "SELECT id_clinica, foto, nome FROM clinica";
                PreparedStatement stmt = con.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();

                // Limpar as listas antes de adicionar novos dados
                listaIdContato.clear();
                listaFotoContato.clear();
                listaNomeContato.clear();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    String id = rs.getString("id_clinica");
                    byte[] fotoBytes = rs.getBytes("foto");
                    String nome = rs.getString("nome");

                    // Default image, caso não tenha imagem no banco
                    Bitmap roundedBitmap;

                    if (fotoBytes != null) {
                        Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);
                        roundedBitmap = getRoundedBitmap(fotoBitmap);

                        // Adicionar os dados nas listas de forma sincronizada
                        listaIdContato.add(id);
                        listaFotoContato.add(roundedBitmap);
                        listaNomeContato.add(nome);
                    }
                }

                // Fechar os recursos
                rs.close();
                stmt.close();
                con.close();

                // Atualize o RecyclerView com os dados
                updateRecyclerView();

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else if (tipoUserAtual.equals("Clinica")) {
            try {
                Connection con = ConexaoMysql.conectar();
                String sql = "SELECT DISTINCT remetente_id_tutor, remetente_foto_tutor, remetente_nome_tutor FROM view_mensagens WHERE destinatario_id_clinica = ?";
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                ResultSet rs = stmt.executeQuery();

                // Limpar as listas antes de adicionar novos dados
                listaIdContato.clear();
                listaFotoContato.clear();
                listaNomeContato.clear();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    String id = rs.getString("remetente_id_tutor");
                    byte[] fotoBytes = rs.getBytes("remetente_foto_tutor");
                    String nome = rs.getString("remetente_nome_tutor");

                    // Default image, caso não tenha imagem no banco
                    Bitmap roundedBitmap;

                    if (fotoBytes != null) {
                        Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);
                        roundedBitmap = getRoundedBitmap(fotoBitmap);
                    } else {
                        // Usar uma imagem padrão do app
                        Bitmap anonimo = BitmapFactory.decodeResource(getResources(), R.drawable.img_anonimo);
                        roundedBitmap = getRoundedBitmap(anonimo);
                    }

                    // Adicionar os dados nas listas de forma sincronizada
                    listaIdContato.add(id);
                    listaFotoContato.add(roundedBitmap);
                    listaNomeContato.add(nome);
                }

                // Fechar os recursos
                rs.close();
                stmt.close();
                con.close();

                // Atualize o RecyclerView com os dados
                updateRecyclerView();

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModels.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdContato.size(); i++) {
            MainModelContato model = new MainModelContato(listaIdContato.get(i), listaFotoContato.get(i), listaNomeContato.get(i));
            mainModels.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapterContato.notifyDataSetChanged();
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }

    public void funMostrarContatos() {
        listaContatos.setVisibility(VISIBLE);
        pesquisarContato.setVisibility(VISIBLE);
        btEnviarMensagem.setVisibility(GONE);
        btVoltarContatos.setVisibility(GONE);
        caixaMensagem.setText(null);
        caixaMensagem.setVisibility(GONE);
        listaMsg.setVisibility(GONE);
        tvContatoNull.setVisibility(GONE);
        funVerificarListaContato();
    }

    public void funMostrarMensagens() {
        listaContatos.setVisibility(GONE);
        pesquisarContato.setVisibility(GONE);
        tvContatoNull.setVisibility(GONE);
        btEnviarMensagem.setVisibility(VISIBLE);
        btVoltarContatos.setVisibility(VISIBLE);
        caixaMensagem.setVisibility(VISIBLE);
        listaMsg.setVisibility(VISIBLE);
    }

    public void funAtualizarMensagens() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT " +
                    "   COALESCE(m.remetente_id_tutor, m.remetente_id_clinica) AS id_remetente, " +
                    "   COALESCE(m.destinatario_id_tutor, m.destinatario_id_clinica) AS id_destinatario, " +
                    "   COALESCE(m.remetente_nome_tutor, m.remetente_nome_clinica) AS nome_remetente, " +
                    "   m.mensagem, " +
                    "   m.id_mensagem " +
                    "FROM view_mensagens m " +
                    "WHERE ( " +
                    "   (COALESCE(m.remetente_id_tutor, m.remetente_id_clinica) = ? AND " +
                    "    COALESCE(m.destinatario_id_tutor, m.destinatario_id_clinica) = ?) " +
                    "   OR " +
                    "   (COALESCE(m.remetente_id_tutor, m.remetente_id_clinica) = ? AND " +
                    "    COALESCE(m.destinatario_id_tutor, m.destinatario_id_clinica) = ?) " +
                    ") " +
                    "ORDER BY m.id_mensagem ASC";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            stmt.setInt(2, idContatoClicado);
            stmt.setInt(3, idContatoClicado);
            stmt.setInt(4, idUsuarioAtual);

            ResultSet rs = stmt.executeQuery();

            mainModelsMsg.clear(); // Limpa mensagens antigas

            while (rs.next()) {
                Integer idRemetente = Integer.valueOf(rs.getString("id_remetente"));
                Integer idDestinatario = Integer.valueOf(rs.getString("id_destinatario"));
                String nomeRemetente = rs.getString("nome_remetente");
                String mensagem = rs.getString("mensagem");

                MainModelMsg modelMsg = new MainModelMsg(idRemetente, idDestinatario, nomeRemetente, mensagem);
                mainModelsMsg.add(modelMsg);
            }

            if (mainAdapterMsg == null) {
                mainAdapterMsg = new MainAdapterMsg(getActivity(), mainModelsMsg, idUsuarioAtual);
                listaMsg.setLayoutManager(new LinearLayoutManager(getActivity()));
                listaMsg.setAdapter(mainAdapterMsg);
            } else {
                mainAdapterMsg.notifyDataSetChanged(); // Atualiza apenas os dados
            }

            rs.close();
            stmt.close();
            con.close();

            if (!mainModelsMsg.isEmpty()) {
                listaMsg.scrollToPosition(mainModelsMsg.size() - 1);
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Erro ao carregar mensagens", Toast.LENGTH_SHORT).show();
        }
    }

    public void funVerificarListaContato() {
        if (listaIdContato.isEmpty()) {
            pesquisarContato.setVisibility(GONE);
            tvContatoNull.setVisibility(VISIBLE);
        } else {
            tvContatoNull.setVisibility(GONE);
            pesquisarContato.setVisibility(VISIBLE);
        }
    }

    public void funPesquisarContato(String termo) {
        if (tipoUserAtual.equals("Tutor")) {
            try {
                Connection con = ConexaoMysql.conectar();
                String sql = "SELECT id_clinica, foto, nome FROM clinica WHERE unaccent(LOWER(nome)) LIKE LOWER(?)";
                PreparedStatement stmt = con.prepareStatement(sql);

                String filtro = "%" + termo.trim() + "%";
                for (int i = 1; i <= 1; i++) {
                    stmt.setString(i, filtro);
                }

                ResultSet rs = stmt.executeQuery();

                // Limpar as listas antes de adicionar novos dados
                listaIdContato.clear();
                listaFotoContato.clear();
                listaNomeContato.clear();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    String id = rs.getString("id_clinica");
                    byte[] fotoBytes = rs.getBytes("foto");
                    String nome = rs.getString("nome");

                    // Default image, caso não tenha imagem no banco
                    Bitmap roundedBitmap;

                    if (fotoBytes != null) {
                        Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);
                        roundedBitmap = getRoundedBitmap(fotoBitmap);

                        // Adicionar os dados nas listas de forma sincronizada
                        listaIdContato.add(id);
                        listaFotoContato.add(roundedBitmap);
                        listaNomeContato.add(nome);
                    }
                }

                // Fechar os recursos
                rs.close();
                stmt.close();
                con.close();

                // Atualize o RecyclerView com os dados
                updateRecyclerView();

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else if (tipoUserAtual.equals("Clinica")) {
            try {
                Connection con = ConexaoMysql.conectar();
                String sql = "SELECT DISTINCT remetente_id_tutor, remetente_foto_tutor, remetente_nome_tutor FROM view_mensagens " +
                        "WHERE destinatario_id_clinica = ? AND unaccent(LOWER(remetente_nome_tutor)) LIKE LOWER(?)";
                PreparedStatement stmt = con.prepareStatement(sql);

                String filtro = "%" + termo.trim() + "%";
                stmt.setInt(1, idUsuarioAtual); // para destinatario_id_clinica
                stmt.setString(2, filtro);         // para remetente_nome_tutor

                ResultSet rs = stmt.executeQuery();

                // Limpar as listas antes de adicionar novos dados
                listaIdContato.clear();
                listaFotoContato.clear();
                listaNomeContato.clear();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    String id = rs.getString("remetente_id_tutor");
                    byte[] fotoBytes = rs.getBytes("remetente_foto_tutor");
                    String nome = rs.getString("remetente_nome_tutor");

                    // Default image, caso não tenha imagem no banco
                    Bitmap roundedBitmap;

                    if (fotoBytes != null) {
                        Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);
                        roundedBitmap = getRoundedBitmap(fotoBitmap);
                    } else {
                        // Usar uma imagem padrão do app
                        Bitmap anonimo = BitmapFactory.decodeResource(getResources(), R.drawable.img_anonimo);
                        roundedBitmap = getRoundedBitmap(anonimo);
                    }

                    // Adicionar os dados nas listas de forma sincronizada
                    listaIdContato.add(id);
                    listaFotoContato.add(roundedBitmap);
                    listaNomeContato.add(nome);
                }

                // Fechar os recursos
                rs.close();
                stmt.close();
                con.close();

                // Atualize o RecyclerView com os dados
                updateRecyclerView();

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

}